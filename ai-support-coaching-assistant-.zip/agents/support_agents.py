from __future__ import annotations

import json
import re
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from models.risk_config import risk_thresholds
from rag.retriever import retrieve_relevant_chunks


POSITIVE_WORDS = {
    "thanks",
    "thank",
    "great",
    "good",
    "helpful",
    "resolved",
    "perfect",
    "awesome",
    "appreciate",
    "clear",
}

NEGATIVE_WORDS = {
    "angry",
    "bad",
    "broken",
    "cancel",
    "complaint",
    "confused",
    "disappointed",
    "frustrated",
    "hate",
    "late",
    "never",
    "nobody",
    "nothing",
    "refund",
    "slow",
    "still",
    "terrible",
    "tired",
    "upset",
    "waiting",
    "wrong",
    "unacceptable",
    "manager",
    "escalate",
    "escalated",
}

INTENT_KEYWORDS = {
    "refund_request": {"refund", "money", "charged", "billing", "cancel"},
    "billing_issue": {"invoice", "payment", "paid", "card", "receipt", "bill", "price", "subscription"},
    "technical_support": {"error", "bug", "login", "password", "crash", "otp", "code", "app", "website"},
    "shipping_status": {"shipping", "delivery", "late", "tracking", "package", "order"},
    "account_change": {"account", "email", "plan", "subscription", "upgrade", "downgrade"},
    "product_information": {"feature", "features", "available", "premium", "use", "setup", "configure", "information"},
    "complaint": {"complaint", "angry", "manager", "unacceptable", "terrible"},
}

SMALL_TALK_KEYWORDS = {
    "greeting": {"hi", "hello", "hey", "yo", "morning", "afternoon", "evening", "sup"},
    "thanks": {"thanks", "thank", "appreciate", "awesome", "great", "cool", "nice"},
    "farewell": {"bye", "goodbye", "later", "cya", "gtg"},
}

# Any word from these sets signals the message is at least support-adjacent,
# even if it does not match a specific intent bucket above.
SUPPORT_CONTEXT_WORDS = set().union(*INTENT_KEYWORDS.values()) | {
    "help",
    "support",
    "issue",
    "problem",
    "order",
    "account",
    "service",
    "request",
    "question",
    "assist",
    "trouble",
}


def small_talk_kind(text: str) -> str | None:
    words = set(tokenize(text))
    if not words:
        return None
    if words & SMALL_TALK_KEYWORDS["greeting"] and len(words) <= 4:
        return "greeting"
    if words & SMALL_TALK_KEYWORDS["farewell"] and len(words) <= 4:
        return "farewell"
    if words & SMALL_TALK_KEYWORDS["thanks"] and len(words) <= 5:
        return "thanks"
    return None

DEFAULT_GUIDANCE = {
    "Billing Support Guidance": (
        "For billing questions, verify account ownership, inspect invoice/payment/subscription records, "
        "explain the charge or payment status, and give the exact correction or follow-up timeline."
    ),
    "Account Management Guidance": (
        "For account changes, verify ownership, confirm the requested change, explain any impact, "
        "and complete the update only after customer confirmation."
    ),
    "Product Support Guidance": (
        "For product questions, identify what the customer wants to do, provide the shortest usable answer, "
        "and offer the next setup or usage step."
    ),
    "General Support Guidance": (
        "For general customer queries, acknowledge the request, identify the needed account/order/product detail, "
        "check the relevant record or policy, and give one concrete next action."
    ),
}

SIMULATED_CUSTOMERS = [
    "I was charged twice this month and I need a refund right now.",
    "My order says delivered, but nothing arrived at my address.",
    "I cannot log in after resetting my password three times.",
    "The agent yesterday promised a callback, and nobody contacted me.",
    "I want to cancel unless someone can fix this today.",
]


@dataclass
class AgentResult:
    name: str
    output: dict[str, Any]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", text.lower())


def keywords_for(text: str) -> set[str]:
    stop = {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "you",
        "your",
        "can",
        "are",
        "from",
        "into",
        "when",
        "have",
        "has",
        "was",
        "were",
    }
    return {word for word in tokenize(text) if len(word) > 2 and word not in stop}


def detect_intent(text: str) -> str:
    words = set(tokenize(text))
    if small_talk_kind(text):
        return "small_talk"
    scores = {intent: len(words & terms) for intent, terms in INTENT_KEYWORDS.items()}
    best_intent, best_score = max(scores.items(), key=lambda item: item[1])
    if best_intent == "technical_support" and not words & {"error", "bug", "login", "password", "crash", "otp", "code", "app", "website"}:
        best_score = 0
    if best_score:
        return best_intent
    # No support-specific keywords matched. If the message still reads as a
    # support-adjacent ask, route it through the general support flow;
    # otherwise treat it as an open, unrelated question the assistant should
    # still answer directly instead of forcing it into a support template.
    if words & SUPPORT_CONTEXT_WORDS:
        return "general_support"
    return "general_question" if words else "general_support"


def detect_sentiment(text: str) -> tuple[str, int]:
    words = set(tokenize(text))
    score = len(words & POSITIVE_WORDS) - len(words & NEGATIVE_WORDS)
    if score <= -2:
        return "negative", score
    if score >= 2:
        return "positive", score
    return "neutral", score


def retrieve_knowledge(conn: sqlite3.Connection, query: str, limit: int = 3) -> list[dict[str, Any]]:
    return retrieve_relevant_chunks(conn, query, limit)


def prioritize_recommendations(intent: str, recommendations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    preferred_source = {
        "refund_request": "Refund Policy",
        "billing_issue": "Billing Support Guidance",
        "technical_support": "Technical Login Help",
        "shipping_status": "Delivery Issue Guide",
        "account_change": "Account Management Guidance",
        "product_information": "Product Support Guidance",
        "complaint": "Escalation Playbook",
    }.get(intent)
    if not preferred_source:
        return recommendations
    return sorted(
        recommendations,
        key=lambda item: 0 if item.get("title") == preferred_source else 1,
    )


def escalation_risk(text: str, sentiment: str, intent: str) -> int:
    lower = text.lower()
    score = 15
    if sentiment == "negative":
        score += 30
    if intent in {"complaint", "refund_request"}:
        score += 20
    if any(term in lower for term in ["manager", "legal", "cancel", "unacceptable", "escalate"]):
        score += 25
    if any(term in lower for term in ["again", "twice", "three times", "nobody", "still"]):
        score += 10
    return min(score, 100)


def risk_level(score: int) -> str:
    thresholds = risk_thresholds()
    if score >= thresholds["high"]:
        return "high"
    if score >= thresholds["medium"]:
        return "medium"
    return "low"


def escalation_alerts(score: int, text: str) -> list[str]:
    alerts = []
    thresholds = risk_thresholds()
    if score >= thresholds["high"]:
        alerts.append("High escalation risk: acknowledge urgency and offer a concrete next step.")
    elif score >= thresholds["medium"]:
        alerts.append("Medium escalation risk: slow down, validate the concern, and keep the next action concrete.")
    if "manager" in text.lower():
        alerts.append("Customer requested management attention.")
    if "cancel" in text.lower():
        alerts.append("Churn risk detected.")
    return alerts


def consolidate_customer_behavior(text: str, sentiment: str, intent: str, risk_score: int) -> dict[str, Any]:
    lower = text.lower()
    signals = []
    if sentiment == "negative":
        signals.append("frustrated or dissatisfied tone")
    if any(term in lower for term in ["again", "twice", "three times", "nobody", "still"]):
        signals.append("repeated-contact or unresolved-issue pattern")
    if any(term in lower for term in ["manager", "escalate", "legal"]):
        signals.append("explicit escalation request")
    if "cancel" in lower:
        signals.append("possible churn/cancellation risk")
    if not signals:
        signals.append("standard support request")

    if risk_score >= risk_thresholds()["high"]:
        engagement_style = "urgent handoff with calm acknowledgement"
    elif sentiment == "negative":
        engagement_style = "empathetic de-escalation before troubleshooting"
    else:
        engagement_style = "direct problem-solving with concise confirmation"

    return {
        "intent": intent,
        "sentiment": sentiment,
        "riskScore": risk_score,
        "signals": signals,
        "engagementStyle": engagement_style,
        "summary": (
            f"Customer appears to have a {intent.replace('_', ' ')} issue with {sentiment} sentiment. "
            f"Best approach: {engagement_style}."
        ),
    }


def build_small_talk_reply(text: str) -> str:
    kind = small_talk_kind(text) or "greeting"
    if kind == "greeting":
        return "Hey there! I'm here and ready to help - ask me anything, whether it's about your account or order, or something else entirely."
    if kind == "farewell":
        return "Take care! I'm right here if anything else comes up."
    return "You're very welcome! Let me know if there's anything else you'd like help with."


def build_general_answer(text: str) -> str:
    clean = text.strip()
    direct = try_deterministic_answer(clean)
    if direct:
        return direct
    return (
        f'"{clean}" isn\'t something I can verify without a connected knowledge model right now, '
        "so I won't guess at it. Happy to keep chatting about it though - and if you've also got an "
        "account, billing, or order question, send it and I will resolve that one immediately."
    )


_MATH_EXPRESSION = re.compile(r"^[\s\d+\-*/().%]+$")
_MATH_TRIGGER = re.compile(r"\b(calculate|compute|what is|what's|solve)\b", re.IGNORECASE)
_JOKES = [
    "Why did the ticket go to therapy? Too many unresolved issues.",
    "I'd tell you a refund joke, but it never pays off.",
    "Why do support agents make great friends? They always follow up.",
]


def try_deterministic_answer(clean_text: str) -> str | None:
    """Answer a handful of question types with certainty instead of a
    generic hedge - arithmetic, date/time, and a few conversational
    staples are things this offline assistant can always get right."""
    lowered = clean_text.lower().strip("? .")

    if lowered in {"what time is it", "what's the time", "current time"}:
        now = datetime.now(timezone.utc)
        return f"It's {now.strftime('%H:%M UTC')} right now (server time, UTC)."

    if lowered in {"what day is it", "what's today's date", "what is today's date", "today's date", "what date is it"}:
        now = datetime.now(timezone.utc)
        return f"Today is {now.strftime('%A, %B %d, %Y')} (UTC)."

    if lowered in {"how are you", "how are you doing", "how's it going", "hows it going"}:
        return "Doing well and ready to help! How can I assist you today?"

    if lowered in {"who are you", "what are you", "what is your name", "what's your name"}:
        return "I'm your AI representative for this chat - I handle account, billing, order, and technical questions, and I'll answer anything else you ask along the way too."

    if lowered in {"what can you do", "what can you help with", "help"}:
        return "I can resolve account, billing, order, and technical issues, and I'll do my best on any other question too. If something needs a human touch, I'll bring in a live representative."

    if "joke" in lowered:
        return _JOKES[hash(lowered) % len(_JOKES)]

    math_candidate = clean_text
    trigger_match = _MATH_TRIGGER.search(clean_text)
    if trigger_match:
        math_candidate = clean_text[trigger_match.end():]
    math_candidate = math_candidate.strip(" ?=")
    if math_candidate and _MATH_EXPRESSION.match(math_candidate) and any(ch.isdigit() for ch in math_candidate):
        try:
            # Restricted to arithmetic characters only (validated by the regex
            # above), so eval here cannot execute arbitrary code.
            result = eval(math_candidate, {"__builtins__": {}}, {})  # noqa: S307
        except Exception:
            result = None
        if isinstance(result, (int, float)):
            pretty = int(result) if float(result).is_integer() else round(result, 6)
            return f"{math_candidate.strip()} = {pretty}"

    return None


def build_precise_solution(
    intent: str,
    recommendations: list[dict[str, Any]],
    behavior_profile: dict[str, Any],
    customer_text: str = "",
) -> dict[str, Any]:
    if intent == "small_talk":
        return {
            "source": "Conversational reply",
            "steps": ["Respond warmly and stay available for a real support question."],
            "answer": build_small_talk_reply(customer_text),
            "style": behavior_profile["engagementStyle"],
        }
    if intent == "general_question":
        return {
            "source": "General knowledge (non-support)",
            "steps": [
                "Recognize the question is unrelated to account/order/billing support.",
                "Answer it directly instead of deflecting.",
                "Invite any real support question in the same reply.",
            ],
            "answer": build_general_answer(customer_text),
            "style": behavior_profile["engagementStyle"],
        }
    action_map = {
        "refund_request": [
            "Verify account ownership and duplicate transaction details.",
            "Confirm refund eligibility using the refund policy.",
            "Give a clear refund timeline or escalation path.",
        ],
        "billing_issue": [
            "Verify the account and billing identifier.",
            "Check invoice, payment status, receipt, or subscription details.",
            "Explain the billing result and next correction step clearly.",
        ],
        "technical_support": [
            "Confirm the affected account and exact error.",
            "Check reset attempts, active sessions, and browser/cache steps.",
            "Avoid asking for passwords and document the troubleshooting result.",
        ],
        "shipping_status": [
            "Confirm order number, tracking status, and shipping address.",
            "Check carrier notes and delivery evidence.",
            "Offer eligible replacement, refund, or case-owner follow-up.",
        ],
        "account_change": [
            "Verify account ownership.",
            "Confirm the requested plan/account change.",
            "Explain the impact and complete the change only after confirmation.",
        ],
        "product_information": [
            "Identify exactly what the customer wants to know or do.",
            "Give the shortest usable answer from available knowledge.",
            "Offer the next setup, usage, or confirmation step.",
        ],
        "complaint": [
            "Acknowledge the complaint without blame.",
            "Summarize the issue and previous failed contacts.",
            "Escalate or provide a concrete next action with ownership.",
        ],
        "general_support": [
            "Acknowledge the customer's request directly.",
            "Ask for the one missing account, order, product, or case detail needed to resolve it.",
            "Check the relevant record or policy and give the next concrete action.",
        ],
    }
    steps = action_map.get(
        intent,
        [
            "Clarify the customer's exact issue.",
            "Match the issue to the most relevant knowledge article.",
            "Provide the next concrete support action.",
        ],
    )
    source = select_solution_source(intent, recommendations)
    return {
        "source": source,
        "steps": steps,
        "answer": (
            f"Use {source}. First acknowledge the customer's situation, then follow: "
            + " ".join(steps)
        ),
        "style": behavior_profile["engagementStyle"],
    }


def build_customer_resolution(
    intent: str,
    recommendations: list[dict[str, Any]],
    solution: dict[str, Any],
    risk_score: int,
) -> dict[str, Any]:
    source = solution.get("source") or "available support knowledge"
    steps = solution.get("steps", [])
    if intent in {"small_talk", "general_question"}:
        return {
            "answer": solution.get("answer", ""),
            "visibleToCustomer": True,
            "source": source,
            "status": "resolved_by_ai",
        }
    if risk_score >= risk_thresholds()["high"]:
        return {
            "answer": (
                "I understand this needs urgent attention. I am transferring this chat to a live "
                "support representative now so they can review the details and resolve it with priority."
            ),
            "visibleToCustomer": True,
            "source": source,
            "status": "handoff",
        }

    intro = {
        "refund_request": "I can help with the refund request.",
        "billing_issue": "I can help with the billing question.",
        "technical_support": "I can help troubleshoot the login or technical issue.",
        "shipping_status": "I can help check the delivery issue.",
        "account_change": "I can help with the account change request.",
        "product_information": "I can help with that product question.",
        "complaint": "I understand the concern and I can help move this forward.",
    }.get(intent, "I can help with this support request.")
    detail = " ".join(steps)
    matched_source = next((item for item in recommendations if item.get("title") == source), None)
    evidence = matched_source["content"] if matched_source else DEFAULT_GUIDANCE.get(source, DEFAULT_GUIDANCE["General Support Guidance"])
    return {
        "answer": f"{intro} Based on {source}: {detail} Guidance: {evidence}",
        "visibleToCustomer": True,
        "source": source,
        "status": "resolved_by_ai",
    }


def build_representative_assist(
    customer_text: str,
    intent: str,
    behavior_profile: dict[str, Any],
    solution: dict[str, Any],
    coaching: list[str],
    risk_score: int,
) -> dict[str, Any]:
    should_take_over = risk_score >= risk_thresholds()["high"]
    source = solution.get("source") or "available support knowledge"
    draft = build_response_suggestion(customer_text, intent, behavior_profile["sentiment"], [{"title": source}], risk_score)
    if should_take_over:
        draft = (
            "I have the context. I will take over from here, verify the account and issue details, "
            f"then resolve it using {source}. {draft}"
        )
    return {
        "assignedTo": "human_representative" if should_take_over else "ai_assistant",
        "priority": "high" if should_take_over else risk_level(risk_score),
        "takeoverRequired": should_take_over,
        "draftReply": draft,
        "resolutionChecklist": solution.get("steps", []),
        "coachNotes": coaching,
        "customerSnapshot": behavior_profile["summary"],
    }


def select_solution_source(intent: str, recommendations: list[dict[str, Any]]) -> str:
    preferred_sources = {
        "refund_request": "Refund Policy",
        "billing_issue": "Billing Support Guidance",
        "technical_support": "Technical Login Help",
        "shipping_status": "Delivery Issue Guide",
        "account_change": "Account Management Guidance",
        "product_information": "Product Support Guidance",
        "complaint": "Escalation Playbook",
        "general_support": "General Support Guidance",
    }
    source_terms = {
        "refund_request": {"refund", "billing", "charge", "charged"},
        "billing_issue": {"invoice", "payment", "card", "receipt", "billing", "subscription"},
        "technical_support": {"login", "password", "technical", "error"},
        "shipping_status": {"delivery", "shipping", "tracking", "package"},
        "account_change": {"account", "subscription", "plan", "email"},
        "product_information": {"feature", "setup", "configure", "product", "usage"},
        "complaint": {"escalation", "complaint", "manager"},
        "general_support": {"support", "help", "question", "request", "problem"},
    }
    expected_terms = source_terms.get(intent, set())
    preferred = preferred_sources.get(intent)
    if preferred:
        for recommendation in recommendations:
            if recommendation.get("title") == preferred:
                return recommendation["title"]
        if preferred in DEFAULT_GUIDANCE:
            return preferred
    for recommendation in recommendations:
        haystack = f"{recommendation.get('title', '')} {recommendation.get('content', '')}".lower()
        if any(term in haystack for term in expected_terms):
            return recommendation["title"]
    if preferred:
        return preferred
    if recommendations:
        return recommendations[0]["title"]
    return "No matching knowledge article"


def build_coaching(
    text: str,
    intent: str,
    sentiment: str,
    recommendations: list[dict[str, Any]],
    risk_score: int,
) -> list[str]:
    coaching = [
        "Reflect the customer's issue in one sentence before troubleshooting.",
        "Ask one verification question at a time.",
    ]
    if sentiment == "negative":
        coaching.insert(0, "Lead with empathy and avoid policy-first language.")
    if intent == "refund_request":
        coaching.append("Confirm charge date and explain refund timing clearly.")
    if intent == "technical_support":
        coaching.append("Protect credentials: never request the customer's password.")
    if risk_score >= risk_thresholds()["high"]:
        coaching.append("Offer escalation or supervisor review after summarizing the case.")
    if recommendations:
        coaching.append(f"Use the '{recommendations[0]['title']}' knowledge article.")
    return coaching


def build_response_suggestion(
    text: str,
    intent: str,
    sentiment: str,
    recommendations: list[dict[str, Any]],
    risk_score: int,
) -> str:
    if intent == "small_talk":
        return build_small_talk_reply(text)
    if intent == "general_question":
        return build_general_answer(text)

    opener = "I understand how frustrating this is, and I can help take ownership of it."
    if sentiment != "negative":
        opener = "Thanks for sharing the details. I can help with that."

    intent_action = {
        "refund_request": "I will verify the charge and check refund eligibility and timeline.",
        "billing_issue": "I will verify the billing record and explain the payment or invoice status.",
        "technical_support": "I will walk through the login checks and keep your account secure.",
        "shipping_status": "I will review the tracking details and confirm the best replacement or refund path.",
        "account_change": "I will review the account settings and confirm the safest way to update them.",
        "product_information": "I will answer the product question and give the next setup or usage step.",
        "complaint": "I will summarize what happened and make sure the next step is clear.",
    }.get(intent, "I will review the details and guide you through the next best step.")

    knowledge = ""
    if recommendations:
        knowledge = f" Based on our {recommendations[0]['title'].lower()},"
    escalation = (
        " If you prefer, I can also involve a supervisor after I document the issue."
        if risk_score >= risk_thresholds()["high"]
        else ""
    )
    return f"{opener}{knowledge} {intent_action}{escalation}"


def run_agents(conn: sqlite3.Connection, session_id: str, customer_text: str) -> dict[str, Any]:
    intent = detect_intent(customer_text)
    sentiment, sentiment_score = detect_sentiment(customer_text)
    recommendations = prioritize_recommendations(intent, retrieve_knowledge(conn, customer_text))
    risk_score = escalation_risk(customer_text, sentiment, intent)
    behavior_profile = consolidate_customer_behavior(customer_text, sentiment, intent, risk_score)
    precise_solution = build_precise_solution(intent, recommendations, behavior_profile, customer_text)
    coaching = build_coaching(customer_text, intent, sentiment, recommendations, risk_score)
    response = build_response_suggestion(customer_text, intent, sentiment, recommendations, risk_score)
    customer_resolution = build_customer_resolution(intent, recommendations, precise_solution, risk_score)
    representative_assist = build_representative_assist(
        customer_text,
        intent,
        behavior_profile,
        precise_solution,
        coaching,
        risk_score,
    )

    results = [
        AgentResult(
            "Intent & Sentiment Analysis Agent",
            {"intent": intent, "sentiment": sentiment, "sentimentScore": sentiment_score},
        ),
        AgentResult("Knowledge Recommendation Agent", {"recommendations": recommendations}),
        AgentResult("Customer Behavior Consolidation Agent", {"behaviorProfile": behavior_profile}),
        AgentResult("Coaching & Response Suggestion Agent", {"coaching": coaching, "response": response}),
        AgentResult("Precise Solution Agent", {"solution": precise_solution}),
        AgentResult("Customer Resolution Agent", {"resolution": customer_resolution}),
        AgentResult("Representative Assist Agent", {"assist": representative_assist}),
        AgentResult(
            "Escalation Risk Monitor Agent",
            {"riskScore": risk_score, "level": risk_level(risk_score), "alerts": escalation_alerts(risk_score, customer_text)},
        ),
    ]

    for result in results:
        conn.execute(
            """
            INSERT INTO agent_events (id, session_id, agent_name, payload, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (str(uuid.uuid4()), session_id, result.name, json.dumps(result.output), utc_now()),
        )

    return {
        "intent": intent,
        "sentiment": sentiment,
        "sentimentScore": sentiment_score,
        "recommendations": recommendations,
        "customerBehavior": behavior_profile,
        "preciseSolution": precise_solution,
        "customerResolution": customer_resolution,
        "representativeAssist": representative_assist,
        "riskScore": risk_score,
        "riskLevel": risk_level(risk_score),
        "alerts": escalation_alerts(risk_score, customer_text),
        "coaching": coaching,
        "suggestedResponse": response,
    }


def session_summary(conn: sqlite3.Connection, session_id: str) -> dict[str, Any]:
    messages = conn.execute(
        "SELECT sender, content, sentiment, intent FROM messages WHERE session_id = ? ORDER BY created_at",
        (session_id,),
    ).fetchall()
    customer_messages = [row for row in messages if row["sender"] == "customer"]
    intents = [row["intent"] for row in customer_messages]
    negatives = [row for row in customer_messages if row["sentiment"] == "negative"]
    events = conn.execute(
        "SELECT payload FROM agent_events WHERE session_id = ? AND agent_name = ?",
        (session_id, "Escalation Risk Monitor Agent"),
    ).fetchall()
    max_risk = 0
    for event in events:
        max_risk = max(max_risk, json.loads(event["payload"]).get("riskScore", 0))

    summary = {
        "messageCount": len(messages),
        "customerTurns": len(customer_messages),
        "primaryIntent": most_common(intents) or "general_support",
        "negativeTurns": len(negatives),
        "maxEscalationRisk": max_risk,
        "score": max(35, 100 - max_risk - len(negatives) * 5),
        "summary": build_plain_summary(customer_messages, max_risk),
        "nextTrainingFocus": training_focus(max_risk, len(negatives)),
    }
    conn.execute(
        """
        INSERT INTO summaries (id, session_id, payload, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(session_id) DO UPDATE SET payload = excluded.payload, created_at = excluded.created_at
        """,
        (str(uuid.uuid4()), session_id, json.dumps(summary), utc_now()),
    )
    return summary


def most_common(items: list[str]) -> str | None:
    if not items:
        return None
    return max(set(items), key=items.count)


def build_plain_summary(customer_messages: list[sqlite3.Row], max_risk: int) -> str:
    if not customer_messages:
        return "No customer turns were recorded."
    issue = customer_messages[-1]["content"]
    return f"Customer discussed: {issue[:180]}. Peak escalation risk was {risk_level(max_risk)}."


def training_focus(max_risk: int, negative_turns: int) -> list[str]:
    focus = ["Maintain concise summaries before proposing actions."]
    if max_risk >= risk_thresholds()["high"]:
        focus.append("Practice de-escalation and supervisor handoff language.")
    if negative_turns:
        focus.append("Use empathy statements before asking diagnostic questions.")
    return focus
