# Agents

The project models six support-coaching agents:

1. Customer Simulator Agent
2. Intent & Sentiment Analysis Agent
3. Knowledge Recommendation Agent
4. Coaching & Response Suggestion Agent
5. Escalation Risk Monitor Agent
6. Post-Interaction Summary Agent

The executable agent logic now lives outside the backend:

- `agents/support_agents.py` - conversation, coaching, escalation, knowledge, and summary agents
- `agents/social_agents.py` - X/Twitter social ingestion and labeling agents
- `agents/orchestrator.py` - coordinates agents, optional LLM enhancement, and live-agent transfer

The backend imports these modules and exposes them through API routes.
