from __future__ import annotations

import json
import os
import re
import sqlite3
import uuid
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from agents.support_agents import detect_intent, detect_sentiment, escalation_risk, keywords_for, risk_level
from models.risk_config import risk_thresholds


DEMO_TWEETS = [
    "Still waiting for support to fix my login issue. Three password resets and nothing works.",
    "Charged twice for my subscription and the refund process is so slow.",
    "Package marked delivered but it never arrived. Need help from support.",
    "The support team solved my billing issue quickly. Really appreciate it.",
    "I am tired of repeating the same complaint. I want this escalated today.",
]


def normalize_social_text(text: str) -> str:
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"@\w+", "@user", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def build_social_label(text: str, language: str = "unknown") -> dict[str, Any]:
    cleaned = normalize_social_text(text)
    intent = detect_intent(cleaned)
    sentiment, sentiment_score = detect_sentiment(cleaned)
    risk_score = escalation_risk(cleaned, sentiment, intent)
    return {
        "content": cleaned,
        "language": language or "unknown",
        "intent": intent,
        "sentiment": sentiment,
        "sentimentScore": sentiment_score,
        "riskScore": risk_score,
        "riskLevel": risk_level(risk_score),
        "keywords": sorted(keywords_for(cleaned)),
    }


def save_social_post(
    conn: sqlite3.Connection,
    *,
    source: str,
    content: str,
    external_id: str | None = None,
    author_id: str | None = None,
    language: str = "unknown",
    raw_payload: dict[str, Any] | None = None,
    posted_at: str | None = None,
) -> dict[str, Any]:
    from backend.app import utc_now

    label = build_social_label(content, language)
    post_id = external_id or str(uuid.uuid4())
    row = {
        "id": post_id if source == "manual" else str(uuid.uuid4()),
        "source": source,
        "external_id": external_id,
        "author_id": author_id,
        "content": label["content"],
        "language": label["language"],
        "intent": label["intent"],
        "sentiment": label["sentiment"],
        "risk_score": label["riskScore"],
        "keywords": json.dumps(label["keywords"]),
        "raw_payload": json.dumps(raw_payload) if raw_payload else None,
        "posted_at": posted_at,
        "created_at": utc_now(),
    }
    conn.execute(
        """
        INSERT OR IGNORE INTO social_posts
        (id, source, external_id, author_id, content, language, intent, sentiment, risk_score, keywords, raw_payload, posted_at, created_at)
        VALUES
        (:id, :source, :external_id, :author_id, :content, :language, :intent, :sentiment, :risk_score, :keywords, :raw_payload, :posted_at, :created_at)
        """,
        row,
    )
    return {**row, "keywords": label["keywords"], "riskLevel": label["riskLevel"]}


def fetch_x_posts(query: str, max_results: int) -> list[dict[str, Any]]:
    token = os.environ.get("X_BEARER_TOKEN", "").strip()
    if not token:
        raise RuntimeError("Set X_BEARER_TOKEN to fetch live X posts, or use demo/manual import.")

    params = urlencode(
        {
            "query": query,
            "max_results": max(10, min(max_results, 100)),
            "tweet.fields": "created_at,lang,author_id",
        }
    )
    request = Request(
        f"https://api.x.com/2/tweets/search/recent?{params}",
        headers={"Authorization": f"Bearer {token}", "User-Agent": "support-coach-demo/1.0"},
    )
    with urlopen(request, timeout=20) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return payload.get("data", [])


def build_training_snapshot(conn: sqlite3.Connection) -> dict[str, Any]:
    from backend.app import utc_now

    rows = conn.execute("SELECT intent, sentiment, risk_score FROM social_posts").fetchall()
    by_intent: dict[str, int] = {}
    by_sentiment: dict[str, int] = {}
    high_risk = 0
    total_risk = 0
    for row in rows:
        by_intent[row["intent"]] = by_intent.get(row["intent"], 0) + 1
        by_sentiment[row["sentiment"]] = by_sentiment.get(row["sentiment"], 0) + 1
        total_risk += row["risk_score"]
        if row["risk_score"] >= risk_thresholds()["high"]:
            high_risk += 1
    total = len(rows)
    snapshot = {
        "examples": total,
        "intentDistribution": by_intent,
        "sentimentDistribution": by_sentiment,
        "highRiskExamples": high_risk,
        "averageRisk": round(total_risk / total) if total else 0,
        "status": "ready" if total >= 10 else "collect_more_data",
        "note": "This snapshot prepares labeled social data for model training or evaluation.",
    }
    conn.execute(
        "INSERT INTO training_snapshots (id, source, payload, created_at) VALUES (?, ?, ?, ?)",
        (str(uuid.uuid4()), "x_social_posts", json.dumps(snapshot), utc_now()),
    )
    return snapshot

