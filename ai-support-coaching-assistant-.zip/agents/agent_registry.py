AGENTS = [
    {
        "name": "Agent Orchestrator",
        "purpose": "Coordinates local agents, optionally enhances coaching through an LLM, and triggers live-agent transfer for high escalation risk.",
        "entrypoint": "agents.orchestrator.run_orchestrator",
    },
    {
        "name": "Live Agent Transfer Agent",
        "purpose": "Transfers high-risk escalations to a live agent.",
        "entrypoint": "agents.orchestrator.live_agent_handoff",
    },
    {
        "name": "Customer Simulator Agent",
        "purpose": "Generates realistic support scenarios for practice.",
        "entrypoint": "agents.support_agents.SIMULATED_CUSTOMERS",
    },
    {
        "name": "Intent & Sentiment Analysis Agent",
        "purpose": "Detects customer intent and sentiment.",
        "entrypoint": "agents.support_agents.detect_intent / detect_sentiment",
    },
    {
        "name": "Customer Behavior Consolidation Agent",
        "purpose": "Consolidates customer emotion, urgency, repeated-contact signals, and best engagement style.",
        "entrypoint": "agents.support_agents.consolidate_customer_behavior",
    },
    {
        "name": "RAG Knowledge Recommendation Agent",
        "purpose": "Retrieves relevant knowledge chunks with local vector RAG.",
        "entrypoint": "agents.support_agents.retrieve_knowledge -> rag.retriever.retrieve_relevant_chunks",
    },
    {
        "name": "Precise Solution Agent",
        "purpose": "Creates a specific step-by-step solution grounded in RAG knowledge and customer behavior.",
        "entrypoint": "agents.support_agents.build_precise_solution",
    },
    {
        "name": "Coaching & Response Suggestion Agent",
        "purpose": "Produces coaching guidance and response suggestions.",
        "entrypoint": "agents.support_agents.build_coaching / build_response_suggestion",
    },
    {
        "name": "Escalation Risk Monitor Agent",
        "purpose": "Scores escalation risk and emits alerts.",
        "entrypoint": "agents.support_agents.escalation_risk / escalation_alerts",
    },
    {
        "name": "Post-Interaction Summary Agent",
        "purpose": "Creates session summary, score, and training focus.",
        "entrypoint": "agents.support_agents.session_summary",
    },
]
