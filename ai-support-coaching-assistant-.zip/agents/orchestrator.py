from __future__ import annotations

import sqlite3
from typing import Any

from agents import support_agents
from models.llm_client import generate_json, llm_settings
from models.system_prompts import SUPPORT_COACH_SYSTEM_PROMPT


def live_agent_handoff(rule_output: dict[str, Any]) -> dict[str, Any]:
    should_transfer = rule_output.get("riskLevel") == "high"
    reason = ""
    if should_transfer:
        reason = "High escalation risk detected. This chat should be transferred to a live agent."
    return {
        "transferToLiveAgent": should_transfer,
        "liveAgentStatus": "transferred" if should_transfer else "not_required",
        "liveAgentReason": reason,
    }


def run_orchestrator(conn: sqlite3.Connection, session_id: str, customer_text: str) -> dict[str, Any]:
    rule_output = support_agents.run_agents(conn, session_id, customer_text)
    handoff = live_agent_handoff(rule_output)
    llm_output = generate_json(
        SUPPORT_COACH_SYSTEM_PROMPT,
        {
            "customerMessage": customer_text,
            "ruleBasedAgentOutput": rule_output,
            "liveAgentHandoff": handoff,
            "expectedJsonShape": {
                "customerBehavior": {
                    "summary": "string",
                    "signals": ["string"],
                    "engagementStyle": "string"
                },
                "preciseSolution": {
                    "answer": "string",
                    "steps": ["string"],
                    "source": "string"
                },
                "customerResolution": {
                    "answer": "string",
                    "status": "resolved_by_ai or handoff",
                    "source": "string"
                },
                "representativeAssist": {
                    "assignedTo": "human_representative or ai_assistant",
                    "priority": "string",
                    "takeoverRequired": "boolean",
                    "draftReply": "string",
                    "resolutionChecklist": ["string"],
                    "coachNotes": ["string"],
                    "customerSnapshot": "string"
                },
                "coaching": ["string"],
                "suggestedResponse": "string",
                "orchestratorNotes": ["string"],
            },
        },
    )
    if not llm_output:
        return {
            **rule_output,
            **handoff,
            "orchestratorMode": "rules_fallback",
            "llmProvider": llm_settings(),
            "orchestratorNotes": [
                "LLM disabled or unavailable; used local rule-based agents.",
                handoff["liveAgentReason"],
            ]
            if handoff["transferToLiveAgent"]
            else ["LLM disabled or unavailable; used local rule-based agents."],
        }

    merged = {
        **rule_output,
        **handoff,
        "orchestratorMode": "llm_enhanced",
        "llmProvider": llm_settings(),
        "orchestratorNotes": llm_output.get("orchestratorNotes", ["LLM enhanced coaching output."]),
    }
    if isinstance(llm_output.get("coaching"), list) and llm_output["coaching"]:
        merged["coaching"] = llm_output["coaching"]
    if isinstance(llm_output.get("customerBehavior"), dict):
        merged["customerBehavior"] = {
            **merged.get("customerBehavior", {}),
            **llm_output["customerBehavior"],
        }
    if isinstance(llm_output.get("preciseSolution"), dict):
        merged["preciseSolution"] = {
            **merged.get("preciseSolution", {}),
            **llm_output["preciseSolution"],
        }
    if isinstance(llm_output.get("customerResolution"), dict):
        merged["customerResolution"] = {
            **merged.get("customerResolution", {}),
            **llm_output["customerResolution"],
        }
    if isinstance(llm_output.get("representativeAssist"), dict):
        merged["representativeAssist"] = {
            **merged.get("representativeAssist", {}),
            **llm_output["representativeAssist"],
        }
    if isinstance(llm_output.get("suggestedResponse"), str) and llm_output["suggestedResponse"].strip():
        merged["suggestedResponse"] = llm_output["suggestedResponse"].strip()
    if handoff["transferToLiveAgent"]:
        merged["customerResolution"] = {
            **merged.get("customerResolution", {}),
            "status": "handoff",
            "answer": (
                "I understand this needs urgent attention. I am transferring this chat to a live "
                "support representative now so they can resolve it with priority."
            ),
        }
        merged["representativeAssist"] = {
            **merged.get("representativeAssist", {}),
            "assignedTo": "human_representative",
            "priority": "high",
            "takeoverRequired": True,
        }
        merged["suggestedResponse"] += " Use the representative assist panel to take over and resolve this."
        if handoff["liveAgentReason"] not in merged["orchestratorNotes"]:
            merged["orchestratorNotes"].append(handoff["liveAgentReason"])
    return merged
