"""Agent modules for the support coaching assistant."""
