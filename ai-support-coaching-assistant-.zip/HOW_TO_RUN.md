# How to Run This Project (and open it in Chrome)

No installs needed — the backend only uses Python's standard library, and the
database is SQLite (also built into Python). You just need Python 3.10+.

## 1. Unzip into a fresh folder

Always extract into a **brand-new folder** rather than overwriting an old one.
Mixing old and new files is the #1 cause of a broken-looking page.

## 2. Start the server

Open a terminal (in VS Code: `` Ctrl+` `` / `` Cmd+` ``), `cd` into the folder
that contains `app.py`, and run:

```bash
python3 app.py
```

(On Windows, use `python app.py` if `python3` isn't recognized.)

You should see:

```text
Support Coaching Assistant running at http://127.0.0.1:8000
SQLite database: .../database/data/support_coach.db
```

Leave this terminal window open — closing it stops the server.

## 3. Open it in Chrome

Go to:

```text
http://127.0.0.1:8000
```

**First time only, or after I send you an updated zip:** do a hard reload so
Chrome doesn't show old cached files instead of the new ones:

- Windows/Linux: `Ctrl + Shift + R`
- Mac: `Cmd + Shift + R`

If it still looks broken/outdated after that, do a full cache wipe for this
page:

1. Open DevTools (`F12`), right-click the reload button (top-left, next to
   the address bar) → **Empty Cache and Hard Reload**.
2. Or go to `chrome://settings/content/all`, search `127.0.0.1`, click it,
   then **Clear data**.
3. Or just test in an **Incognito window** (`Ctrl+Shift+N`) first — if it
   looks correct there, it confirms the problem is Chrome's cache, not the
   code.

## 4. Stop the server

Go back to the terminal and press `Ctrl+C`.

## Optional: turn on real AI answers

By default the app runs its own built-in rule-based assistant (no internet
needed). To have it use a real language model instead for open-ended
questions, set an API key before starting it:

```bash
export OPENAI_API_KEY="your_key_here"   # Mac/Linux
$env:OPENAI_API_KEY="your_key_here"     # Windows PowerShell
python3 app.py
```

## Troubleshooting checklist

| Symptom | Fix |
|---|---|
| Page looks unstyled or half-broken | Hard reload (`Ctrl+Shift+R`), then try Incognito to confirm it's caching |
| "This site can't be reached" | The server isn't running — check the terminal, run `python3 app.py` again |
| Port already in use | Another instance is still running — close that terminal, or set `$env:APP_PORT="8010"` before running |
| Changes I send don't show up | You're likely running an old extracted folder — unzip fresh, restart the server, hard reload |

See `README.md` for the full project structure, environment variables, and
architecture details.
