# AI Support Coaching Assistant

A full-stack local prototype for an AI-powered real-time customer support coaching assistant.

The app includes:

- Frontend: vanilla HTML, CSS, and JavaScript
- Backend: Python standard-library HTTP API
- Database: SQLite
- Streamlit hosting app: optional `streamlit_app.py`
- Agents: customer simulator, intent/sentiment analysis, knowledge recommendation, coaching suggestions, escalation monitoring, and post-interaction summary
- Knowledge layer: document upload, chunking, keyword search, and recommendation retrieval
- Social pipeline: manual/demo tweet ingestion, optional X API fetch, labeling, and training snapshots

## Project Structure

```text
app.py                 Root launcher
backend/               Python backend API
agents/                Agent registry and agent documentation
models/                Local model/rule configuration
frontend/public/       HTML, CSS, and JavaScript frontend
database/data/         SQLite database
rag/                   Local RAG embeddings and retrieval
streamlit_app.py       Streamlit hosting entry point
outputs/               Packaged zip deliverables
```

Agent logic is separated from the backend:

- `agents/orchestrator.py`
- `agents/support_agents.py`
- `agents/social_agents.py`
- `rag/retriever.py`

The frontend accepts free-text customer problems. The orchestrator uses AI when configured,
falls back to local agents when no API key is available, and automatically transfers
high-risk escalations to a live agent.

The conversation flow is:

```text
Customer query -> behavior consolidation -> RAG retrieval -> precise AI solution -> coaching/response -> live-agent transfer if high risk
```

The knowledge layer now uses local RAG:

```text
Documents -> chunks -> local embeddings -> SQLite rag_vectors -> retrieved context -> LLM/orchestrator
```

## Run

Standard full-stack app:

```powershell
python app.py
```

Then open:

```text
http://127.0.0.1:8000
```

Streamlit-hosted app:

```powershell
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Optional Environment

```powershell
$env:APP_HOST="127.0.0.1"
$env:APP_PORT="8000"
$env:X_BEARER_TOKEN="your_x_api_bearer_token"
$env:RISK_MEDIUM_THRESHOLD="40"
$env:RISK_HIGH_THRESHOLD="70"
$env:OPENAI_API_KEY="your_openai_api_key"
$env:LLM_PROVIDER="openai"
$env:LLM_MODEL="gpt-4o-mini"
$env:LLM_ENABLED="true"
```

The database is created at `database/data/support_coach.db`.

## Risk Thresholds

Escalation risk is scored from `0` to `100`.

- Low risk: below `RISK_MEDIUM_THRESHOLD`
- Medium risk: from `RISK_MEDIUM_THRESHOLD` to below `RISK_HIGH_THRESHOLD`
- High risk: `RISK_HIGH_THRESHOLD` and above

Defaults:

```text
RISK_MEDIUM_THRESHOLD=40
RISK_HIGH_THRESHOLD=70
```

## LLM And Orchestration

The app now includes:

- `agents/orchestrator.py` - coordinates agent workflow
- `models/llm_client.py` - optional OpenAI-compatible LLM client
- `models/system_prompts.py` - system prompts for coaching, intent, knowledge, response, and escalation
- `rag/retriever.py` - retrieves grounded knowledge context for RAG

If `OPENAI_API_KEY` is not set, the orchestrator automatically uses the local rule-based agents.

High-risk escalation behavior:

- Risk score reaches `RISK_HIGH_THRESHOLD`
- `transferToLiveAgent` becomes `true`
- The chat receives an automatic live-agent transfer message
- The UI highlights the handoff status

## X / Twitter Pipeline

The app can ingest social posts in three ways:

- Import built-in demo tweets from the Social Pipeline panel.
- Paste one tweet/post per line for manual import.
- Fetch live recent X posts when `X_BEARER_TOKEN` is set.

Each imported post is cleaned, labeled with intent/sentiment, scored for escalation risk, and stored in SQLite. Use **Create Training Snapshot** to summarize labeled examples for later model training or evaluation.

Live X API example query:

```text
("refund" OR "support") lang:en -is:retweet
```
