from __future__ import annotations

import os
import uuid

import streamlit as st

from backend import app as core


st.set_page_config(page_title="AI Support Coaching Assistant", layout="wide")


def ensure_session() -> str:
    if "session_id" not in st.session_state:
        st.session_state.session_id = str(uuid.uuid4())
        with core.db() as conn:
            now = core.utc_now()
            conn.execute(
                "INSERT OR IGNORE INTO sessions (id, title, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (st.session_state.session_id, "Streamlit Coaching Session", "active", now, now),
            )
    return st.session_state.session_id


def save_customer_message(session_id: str, content: str) -> dict:
    sentiment, _score = core.detect_sentiment(content)
    intent = core.detect_intent(content)
    message = {
        "id": str(uuid.uuid4()),
        "session_id": session_id,
        "sender": "customer",
        "content": content,
        "sentiment": sentiment,
        "intent": intent,
        "created_at": core.utc_now(),
    }
    with core.db() as conn:
        conn.execute(
            """
            INSERT INTO messages (id, session_id, sender, content, sentiment, intent, created_at)
            VALUES (:id, :session_id, :sender, :content, :sentiment, :intent, :created_at)
            """,
            message,
        )
        conn.execute("UPDATE sessions SET updated_at = ? WHERE id = ?", (core.utc_now(), session_id))
        output = core.run_orchestrator(conn, session_id, content)
    return output


def get_analytics() -> dict:
    with core.db() as conn:
        sessions = conn.execute("SELECT COUNT(*) AS count FROM sessions").fetchone()["count"]
        messages = conn.execute("SELECT COUNT(*) AS count FROM messages").fetchone()["count"]
        documents = conn.execute("SELECT COUNT(*) AS count FROM knowledge_documents").fetchone()["count"]
        rag_vectors = conn.execute("SELECT COUNT(*) AS count FROM rag_vectors").fetchone()["count"]
        social_posts = conn.execute("SELECT COUNT(*) AS count FROM social_posts").fetchone()["count"]
    return {
        "Sessions": sessions,
        "Messages": messages,
        "Documents": documents,
        "RAG vectors": rag_vectors,
        "Social posts": social_posts,
    }


core.init_db()

st.sidebar.title("Settings")
medium_threshold = st.sidebar.slider("Medium risk threshold", 0, 99, core.risk_thresholds()["medium"])
high_threshold = st.sidebar.slider("High risk threshold", medium_threshold + 1, 100, core.risk_thresholds()["high"])
os.environ["RISK_MEDIUM_THRESHOLD"] = str(medium_threshold)
os.environ["RISK_HIGH_THRESHOLD"] = str(high_threshold)
st.sidebar.write("LLM mode")
st.sidebar.json(core.llm_settings())

st.title("AI-Powered Customer Support Coaching Assistant")
st.caption("Streamlit hosting entry point using the same SQLite database and agent logic.")

conversation_tab, knowledge_tab, social_tab, analytics_tab = st.tabs(
    ["Conversation", "Knowledge", "Social Pipeline", "Analytics"]
)

with conversation_tab:
    session_id = ensure_session()
    st.subheader("Live Coaching")
    customer_text = st.text_area(
        "Customer message",
        placeholder="Write any customer problem and AI will suggest the next step...",
        height=120,
    )
    if st.button("Run Agents", type="primary"):
        st.session_state.last_output = save_customer_message(session_id, customer_text)

    output = st.session_state.get("last_output")
    if output:
        col1, col2, col3 = st.columns(3)
        col1.metric("Intent", output["intent"].replace("_", " "))
        col2.metric("Sentiment", output["sentiment"])
        col3.metric("Risk", f'{output["riskScore"]} ({output["riskLevel"]})')
        st.caption(f"Orchestrator mode: {output.get('orchestratorMode', 'rules_fallback')}")
        if output.get("transferToLiveAgent"):
            st.error(output.get("liveAgentReason", "Transferred to a live agent."))
        else:
            st.success("Live agent transfer not required.")

        st.subheader("Customer Behavior Consolidation")
        behavior = output.get("customerBehavior", {})
        st.write(behavior.get("summary", "No behavior profile available."))
        for signal in behavior.get("signals", []):
            st.write(f"- {signal}")

        st.subheader("Precise Solution")
        solution = output.get("preciseSolution", {})
        st.info(solution.get("answer", "No precise solution available."))
        for step in solution.get("steps", []):
            st.write(f"- {step}")

        st.subheader("Coaching")
        for item in output["coaching"]:
            st.write(f"- {item}")

        st.subheader("Suggested Response")
        st.info(output["suggestedResponse"])

        st.subheader("Knowledge Recommendations")
        for rec in output["recommendations"]:
            st.write(f"**{rec['title']}** - score {rec['score']}")
            st.write(rec["content"])

        if output["alerts"]:
            st.subheader("Escalation Alerts")
            for alert in output["alerts"]:
                st.warning(alert)

with knowledge_tab:
    st.subheader("Knowledge Documents")
    with st.form("add_document"):
        title = st.text_input("Document title")
        content = st.text_area("Document content", height=160)
        submitted = st.form_submit_button("Add Document")
        if submitted and content.strip():
            with core.db() as conn:
                core.add_document(conn, title or "Untitled Document", content)
            st.success("Document indexed.")

    with core.db() as conn:
        docs = conn.execute(
            """
            SELECT kd.title, kd.created_at, COUNT(kc.id) AS chunks
            FROM knowledge_documents kd
            LEFT JOIN knowledge_chunks kc ON kc.document_id = kd.id
            GROUP BY kd.id
            ORDER BY kd.created_at DESC
            """
        ).fetchall()
    st.dataframe([dict(row) for row in docs], use_container_width=True)

with social_tab:
    st.subheader("X / Twitter Training Data")
    if st.button("Import Demo Tweets"):
        with core.db() as conn:
            for text in core.DEMO_TWEETS:
                core.save_social_post(conn, source="demo_x", content=text, language="en")
        st.success("Demo tweets imported.")

    manual_posts = st.text_area("Manual tweet/post import", placeholder="One post per line", height=140)
    if st.button("Import Manual Posts") and manual_posts.strip():
        with core.db() as conn:
            for text in manual_posts.splitlines():
                if text.strip():
                    core.save_social_post(conn, source="manual", content=text, language="en")
        st.success("Manual posts imported.")

    x_query = st.text_input("Live X query", value='("refund" OR "support") lang:en -is:retweet')
    if st.button("Fetch Live X Posts"):
        try:
            posts = core.fetch_x_posts(x_query, 10)
            with core.db() as conn:
                for post in posts:
                    core.save_social_post(
                        conn,
                        source="x_api",
                        external_id=post.get("id"),
                        author_id=post.get("author_id"),
                        content=post.get("text", ""),
                        language=post.get("lang") or "unknown",
                        raw_payload=post,
                        posted_at=post.get("created_at"),
                    )
            st.success(f"Imported {len(posts)} posts.")
        except Exception as exc:
            st.error(str(exc))

    if st.button("Create Training Snapshot", type="primary"):
        with core.db() as conn:
            st.json(core.build_training_snapshot(conn))

    with core.db() as conn:
        posts = conn.execute(
            """
            SELECT source, content, intent, sentiment, risk_score, created_at
            FROM social_posts
            ORDER BY created_at DESC
            LIMIT 100
            """
        ).fetchall()
    st.dataframe([dict(row) for row in posts], use_container_width=True)

with analytics_tab:
    st.subheader("Analytics")
    analytics = get_analytics()
    cols = st.columns(len(analytics))
    for col, (label, value) in zip(cols, analytics.items()):
        col.metric(label, value)
    st.write("Active risk thresholds")
    st.json(core.risk_thresholds())
    st.write("LLM settings")
    st.json(core.llm_settings())
