# Frontend

The browser frontend is in `frontend/public`:

- `index.html`
- `styles.css`
- `app.js`

It talks to the Python backend through `/api/*` endpoints.

