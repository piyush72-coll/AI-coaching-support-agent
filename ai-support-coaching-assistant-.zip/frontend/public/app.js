const state = {
  sessions: [],
  currentSessionId: null,
  lastAgentOutput: null,
};

const $ = (selector) => document.querySelector(selector);

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function renderList(target, items, renderer, emptyText = "No data yet.") {
  target.innerHTML = "";
  if (!items || items.length === 0) {
    target.innerHTML = `<p class="muted">${emptyText}</p>`;
    return;
  }
  items.forEach((item) => target.appendChild(renderer(item)));
}

async function boot() {
  try {
    await api("/api/health");
    $("#healthStatus").innerHTML = '<span class="status-dot"></span>Backend online';
  } catch {
    $("#healthStatus").innerHTML = '<span class="status-dot"></span>Backend unavailable';
    $("#healthStatus").style.color = "var(--red)";
    $("#healthStatus").style.background = "var(--red-bg)";
    $("#healthStatus").style.borderColor = "#fecdca";
  }
  await refreshSessions();
  await refreshDocuments();
  await refreshSocialPosts();
  await refreshAnalytics();
  if (!state.currentSessionId) {
    await createSession();
  }
}

async function refreshSessions() {
  state.sessions = await api("/api/sessions");
  const list = $("#sessionList");
  renderList(
    list,
    state.sessions,
    (session) => {
      const button = document.createElement("button");
      button.className = `session-item ${session.status === "needs_human" ? "needs-human" : ""}`;
      button.textContent = session.status === "needs_human" ? `${session.title} - needs you` : session.title;
      button.onclick = () => loadSession(session.id);
      return button;
    },
    "No sessions yet."
  );
}

async function createSession() {
  const session = await api("/api/sessions", {
    method: "POST",
    body: JSON.stringify({ title: `Coaching Session ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` }),
  });
  state.currentSessionId = session.id;
  await refreshSessions();
  await loadSession(session.id);
}

async function loadSession(id) {
  state.currentSessionId = id;
  const data = await api(`/api/sessions/${id}`);
  $("#sessionTitle").textContent = data.session.title;
  renderMessages(data.messages);
  renderEvents(data.events);
  renderSummary(data.summary);
  renderSessionEndState(data.summary);
}

function shortenForChat(text = "") {
  const clean = text.trim();
  if (!clean) return { short: "", hasMore: false };
  const sentenceMatch = clean.match(/^.*?[.!?](?:\s|$)/);
  let short = sentenceMatch ? sentenceMatch[0].trim() : clean;
  if (short.length > 170) {
    short = `${short.slice(0, 167).trim()}...`;
  }
  return { short, hasMore: short !== clean };
}

const ICONS = {
  bot: '<svg class="icon" viewBox="0 0 24 24"><rect x="4" y="8" width="16" height="12" rx="3"/><circle cx="9" cy="14" r="1.3"/><circle cx="15" cy="14" r="1.3"/><line x1="12" y1="8" x2="12" y2="4"/><circle cx="12" cy="3" r="1"/></svg>',
  user: '<svg class="icon" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  transfer: '<svg class="icon" viewBox="0 0 24 24"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
  rep: '<svg class="icon" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><polyline points="17 11 19 13 23 9"/></svg>',
};

function messageMeta(message) {
  const isRep = message.intent === "representative_reply";
  const isAi = (message.sender === "ai" || message.sender === "agent") && !isRep;
  const isHandoff = message.intent === "live_agent_handoff";
  const label = isHandoff ? "Session update" : isRep ? "Representative" : isAi ? "AI Representative" : "You";
  const avatar = isHandoff ? ICONS.transfer : isRep ? ICONS.rep : isAi ? ICONS.bot : ICONS.user;
  const cssClass = isHandoff ? "handoff" : isRep ? "rep" : isAi ? "ai" : "customer";
  return { isAi, isHandoff, isRep, label, avatar, cssClass };
}

function buildMessageBubble(message) {
  const { isAi, isHandoff, isRep, label, avatar, cssClass } = messageMeta(message);
  const div = document.createElement("div");
  div.className = `message ${cssClass}`;

  const full = message.content;
  const shouldShorten = isAi && !isHandoff && !isRep;
  const { short, hasMore } = shouldShorten ? shortenForChat(full) : { short: full, hasMore: false };

  div.innerHTML = `
    <div class="message-row">
      <span class="avatar">${avatar}</span>
      <div class="message-body">
        <strong>${label}</strong>
        <span class="message-text"></span>
        ${hasMore ? '<span class="message-full" hidden></span><button type="button" class="show-more">View full resolution</button>' : ""}
      </div>
    </div>
  `;
  div.querySelector(".message-text").textContent = short;
  if (hasMore) {
    div.querySelector(".message-full").textContent = full;
    const btn = div.querySelector(".show-more");
    btn.addEventListener("click", () => {
      const fullSpan = div.querySelector(".message-full");
      const shortSpan = div.querySelector(".message-text");
      const expanding = fullSpan.hidden;
      fullSpan.hidden = !expanding;
      shortSpan.hidden = expanding;
      btn.textContent = expanding ? "Show less" : "View full resolution";
    });
  }
  return div;
}

function renderMessages(messages) {
  const box = $("#messages");
  box.innerHTML = "";
  if (messages.length === 0) {
    box.innerHTML = `
      <div class="message ai">
        <div class="message-row">
          <span class="avatar">${ICONS.bot}</span>
          <div class="message-body">
            <strong>AI Representative</strong>
            <span>Hi, thanks for reaching out - I'm your AI representative. Tell me what's going on and I'll get you a resolution right away. If it needs extra attention, I'll bring in a live representative for you.</span>
          </div>
        </div>
      </div>
    `;
    return;
  }
  messages.forEach((message) => {
    box.appendChild(buildMessageBubble(message));
  });
  box.scrollTop = box.scrollHeight;
}

function appendOptimisticCustomerMessage(content) {
  const box = $("#messages");
  if (box.querySelector(".muted")) box.innerHTML = "";
  box.appendChild(
    buildMessageBubble({ sender: "customer", content, intent: "customer_message" })
  );
  box.scrollTop = box.scrollHeight;
}

function showTypingIndicator() {
  const box = $("#messages");
  const div = document.createElement("div");
  div.id = "typingIndicator";
  div.className = "message ai typing";
  div.innerHTML = `
    <div class="message-row">
      <span class="avatar">${ICONS.bot}</span>
      <div class="message-body">
        <strong>AI Representative</strong>
        <span class="typing-dots"><span></span><span></span><span></span></span>
      </div>
    </div>
  `;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
}

function hideTypingIndicator() {
  const el = $("#typingIndicator");
  if (el) el.remove();
}

function renderEvents(events) {
  const latest = events.find((event) => event.agent_name === "Escalation Risk Monitor Agent");
  const analysis = events.find((event) => event.agent_name === "Intent & Sentiment Analysis Agent");
  const knowledge = events.find((event) => event.agent_name === "Knowledge Recommendation Agent");
  const behavior = events.find((event) => event.agent_name === "Customer Behavior Consolidation Agent");
  const solution = events.find((event) => event.agent_name === "Precise Solution Agent");
  const customerResolution = events.find((event) => event.agent_name === "Customer Resolution Agent");
  const representativeAssist = events.find((event) => event.agent_name === "Representative Assist Agent");
  const coaching = events.find((event) => event.agent_name === "Coaching & Response Suggestion Agent");

  if (analysis) {
    $("#intentMetric").textContent = analysis.payload.intent.replaceAll("_", " ");
    $("#sentimentMetric").textContent = analysis.payload.sentiment;
  }

  if (latest) {
    updateRisk(latest.payload.riskScore, latest.payload.level);
    renderAlerts(latest.payload.alerts);
  }

  if (knowledge) {
    renderRecommendations(knowledge.payload.recommendations);
  }

  if (behavior) {
    renderBehavior(behavior.payload.behaviorProfile);
  }

  if (solution) {
    renderPreciseSolution(solution.payload.solution);
  }

  if (customerResolution) {
    renderCustomerResolution(customerResolution.payload.resolution);
  }

  if (representativeAssist) {
    renderRepresentativeAssist(representativeAssist.payload.assist);
  }

  if (coaching) {
    renderCoaching(coaching.payload.coaching);
    $("#suggestedResponse").textContent = buildMoreAiResponses({
      suggestedResponse: coaching.payload.response,
      preciseSolution: solution?.payload.solution,
      riskLevel: latest?.payload.level,
    });
  }

  renderIntentTab({
    intent: analysis?.payload.intent,
    sentiment: analysis?.payload.sentiment,
    riskScore: latest?.payload.riskScore,
    riskLevel: latest?.payload.level,
    customerBehavior: behavior?.payload.behaviorProfile,
    preciseSolution: solution?.payload.solution,
    customerResolution: customerResolution?.payload.resolution,
    representativeAssist: representativeAssist?.payload.assist,
    transferToLiveAgent: representativeAssist?.payload.assist?.takeoverRequired,
    liveAgentReason: representativeAssist?.payload.assist?.takeoverRequired
      ? "High-risk query transferred to representative."
      : "AI can answer this query directly.",
  });
}

function updateRisk(score = 0, level = "low") {
  const badge = $("#riskBadge");
  badge.className = `risk ${level}`;
  badge.textContent = `${level} risk · ${score}`;
  const fill = $("#riskMeterFill");
  if (fill) {
    fill.style.width = `${Math.max(4, Math.min(100, score))}%`;
    fill.className = level;
  }
}

function renderCoaching(items = []) {
  const list = $("#coachingList");
  list.innerHTML = "";
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderAlerts(items = []) {
  const list = $("#alerts");
  list.innerHTML = "";
  if (items.length === 0) {
    const li = document.createElement("li");
    li.textContent = "No escalation alerts.";
    list.appendChild(li);
  }
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderRecommendations(items = []) {
  const box = $("#recommendations");
  box.innerHTML = "";
  if (items.length === 0) {
    box.innerHTML = `<p>No matching knowledge found.</p>`;
    return;
  }
  items.forEach((item) => {
    const div = document.createElement("div");
    div.className = "recommendation";
    div.innerHTML = `<strong></strong><p></p>`;
    div.querySelector("strong").textContent = `${item.title} · score ${item.score}`;
    div.querySelector("p").textContent = item.content;
    box.appendChild(div);
  });
}

async function sendMessage(event) {
  event.preventDefault();
  if (!state.currentSessionId) {
    await createSession();
  }
  const content = $("#messageInput").value.trim();
  if (!content) return;
  $("#messageInput").value = "";
  appendOptimisticCustomerMessage(content);
  showTypingIndicator();
  setComposerBusy(true);
  try {
    const data = await api(`/api/sessions/${state.currentSessionId}/messages`, {
      method: "POST",
      body: JSON.stringify({ content }),
    });
    if (data.agentOutput) {
      state.lastAgentOutput = data.agentOutput;
      applyAgentOutput(data.agentOutput);
    }
    await loadSession(state.currentSessionId);
    await refreshAnalytics();
  } finally {
    hideTypingIndicator();
    setComposerBusy(false);
  }
}

async function sendRepresentativeReply(event) {
  event.preventDefault();
  if (!state.currentSessionId) return;
  const content = $("#repReplyText").value.trim();
  if (!content) return;
  const button = $("#repReplyForm .rep-reply-send");
  button.disabled = true;
  button.textContent = "Sending...";
  try {
    await api(`/api/sessions/${state.currentSessionId}/messages`, {
      method: "POST",
      body: JSON.stringify({ sender: "agent", content }),
    });
    $("#repReplyText").value = "";
    await loadSession(state.currentSessionId);
    await refreshAnalytics();
  } finally {
    button.disabled = false;
    button.textContent = "Send Representative Reply";
  }
}

function setComposerBusy(isBusy) {
  const button = $("#messageForm button[type='submit']");
  button.disabled = isBusy;
  button.querySelector(".btn-label").textContent = isBusy ? "Thinking..." : "Send";
}

function applyAgentOutput(output) {
  $("#intentMetric").textContent = output.intent.replaceAll("_", " ");
  $("#sentimentMetric").textContent = output.sentiment;
  updateRisk(output.riskScore, output.riskLevel);
  renderBehavior(output.customerBehavior);
  renderCustomerResolution(output.customerResolution);
  renderRepresentativeAssist(output.representativeAssist);
  renderPreciseSolution(output.preciseSolution);
  renderCoaching(output.coaching);
  renderOrchestrator(output);
  renderRecommendations(output.recommendations);
  renderAlerts(output.alerts);
  $("#suggestedResponse").textContent = buildMoreAiResponses(output);
  renderIntentTab(output);
}

function buildMoreAiResponses(output = {}) {
  const response = output.suggestedResponse || "No extra response suggestion available.";
  const efficiency =
    output.riskLevel === "high"
      ? "Efficiency tip: transfer quickly after confirming the issue and summarizing ownership."
      : "Efficiency tip: ask one verification question, then give the next action and timeline.";
  const source = output.preciseSolution?.source
    ? `Knowledge source: ${output.preciseSolution.source}.`
    : "Knowledge source: no matching article.";
  return `${response}\n\n${efficiency}\n${source}`;
}

function renderCustomerResolution(resolution = {}) {
  $("#customerResolution").textContent = resolution.answer || "Customer-facing AI resolution will appear here.";
}

function renderRepresentativeAssist(assist = {}) {
  const takeover = Boolean(assist.takeoverRequired);
  const priority = assist.priority || "low";
  const card = $("#representativeAssistCard");
  card.className = `assist-card ${takeover ? "needs-human" : ""}`;
  $("#assistStatus").textContent = takeover ? "Transferred to you" : "AI handling";
  const badge = $("#assistPriority");
  badge.className = `risk ${priority === "high" ? "high" : priority === "medium" ? "medium" : "low"}`;
  badge.textContent = priority;
  $("#assistSnapshot").textContent = assist.customerSnapshot || "No customer snapshot yet.";
  $("#assistDraft").textContent = assist.draftReply || "No representative draft yet.";
  const owner = $("#repOwner");
  if (owner && !owner.matches(":focus")) {
    owner.value = assist.assignedTo === "human_representative" ? "human_representative" : "ai_assistant";
  }
  if (assist.draftReply && document.activeElement !== $("#repReplyText") && !$("#repReplyText").value) {
    $("#repReplyText").placeholder = takeover
      ? "Type your representative reply after high escalation..."
      : "Type a reply to send as the representative (optional while AI is handling)...";
  }
  const list = $("#assistChecklist");
  list.innerHTML = "";
  (assist.resolutionChecklist || []).forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderIntentTab(output = {}) {
  const intent = output.intent || "general_support";
  const sentiment = output.sentiment || "neutral";
  const riskLevel = output.riskLevel || "low";
  const riskScore = output.riskScore ?? 0;
  const behavior = output.customerBehavior || {};
  const solution = output.preciseSolution || {};
  const resolution = output.customerResolution || {};
  const assist = output.representativeAssist || {};
  const route = output.transferToLiveAgent || assist.takeoverRequired ? "Representative" : "AI Resolution";

  $("#heroIntent").textContent = `Intent: ${intent.replaceAll("_", " ")}`;
  $("#heroRoute").textContent = `Route: ${route}`;
  $("#liveIntent").textContent = intent.replaceAll("_", " ");
  $("#liveSentiment").textContent = sentiment;
  $("#liveRisk").textContent = `${riskLevel} (${riskScore})`;
  $("#liveRoute").textContent = route;
  $("#intentTabTitle").textContent = intent.replaceAll("_", " ");
  $("#intentTabSummary").textContent = behavior.summary || "Intent detected from customer query.";
  $("#intentTabSentiment").textContent = `Sentiment: ${sentiment}`;
  $("#intentTabRisk").textContent = `Risk: ${riskLevel} (${riskScore})`;
  $("#intentTabRoute").textContent = `Route: ${route}`;
  $("#intentSource").textContent = solution.source || resolution.source || "No RAG source yet";
  $("#intentResolutionPreview").textContent =
    resolution.answer || solution.answer || "Resolution preview will appear here.";
  $("#intentRoutingTitle").textContent =
    route === "Representative" ? "Transfer to representative" : "AI answers customer";
  $("#intentRoutingReason").textContent =
    route === "Representative"
      ? assist.customerSnapshot || output.liveAgentReason || "High escalation risk detected."
      : "Risk is low or medium, so AI can answer using retrieved support knowledge.";

  const list = $("#intentSignals");
  list.innerHTML = "";
  (behavior.signals || ["No behavior signals yet."]).forEach((signal) => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}

function renderBehavior(behavior = {}) {
  $("#behaviorSummary").textContent = behavior.summary || "No behavior profile available.";
  const list = $("#behaviorSignals");
  list.innerHTML = "";
  (behavior.signals || []).forEach((signal) => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}

function renderPreciseSolution(solution = {}) {
  $("#preciseSolution").textContent = solution.answer || "No precise solution available.";
  const list = $("#solutionSteps");
  list.innerHTML = "";
  (solution.steps || []).forEach((step) => {
    const li = document.createElement("li");
    li.textContent = step;
    list.appendChild(li);
  });
}

function renderOrchestrator(output = {}) {
  $("#orchestratorMode").textContent = output.orchestratorMode || "rules_fallback";
  const handoff = $("#liveAgentStatus");
  if (output.transferToLiveAgent) {
    handoff.className = "handoff-status transferred";
    handoff.textContent = output.liveAgentReason || "Transferred to a live agent.";
  } else {
    handoff.className = "handoff-status";
    handoff.textContent = "Live agent transfer not required.";
  }
  const list = $("#orchestratorNotes");
  list.innerHTML = "";
  (output.orchestratorNotes || []).forEach((note) => {
    const li = document.createElement("li");
    li.textContent = note;
    list.appendChild(li);
  });
}

async function endSession() {
  if (!state.currentSessionId) return;
  const button = $("#endSessionBtn");
  button.disabled = true;
  try {
    const summary = await api(`/api/sessions/${state.currentSessionId}/summary`, {
      method: "POST",
      body: JSON.stringify({}),
    });
    renderSummary(summary);
    renderSessionEndState(summary);
    await refreshSessions();
    await refreshAnalytics();
  } finally {
    button.disabled = false;
  }
}

function renderSessionEndState(summary) {
  const statusEl = $("#sessionEndStatus");
  const pdfLink = $("#downloadPdfBtn");
  if (!summary || !state.currentSessionId) {
    statusEl.textContent = "Session in progress";
    pdfLink.hidden = true;
    return;
  }
  statusEl.textContent = `Resolved - satisfaction score ${summary.score}/100`;
  pdfLink.href = `/api/reports/session.pdf?id=${state.currentSessionId}`;
  pdfLink.hidden = false;
}

function renderSummary(summary) {
  const card = $("#summaryCard");
  if (!summary) {
    card.innerHTML = "Post-interaction summary will appear here.";
    return;
  }
  card.innerHTML = `
    <strong>Score ${summary.score}</strong>
    <p>${summary.summary}</p>
    <p><strong>Primary intent:</strong> ${summary.primaryIntent.replaceAll("_", " ")}</p>
    <p><strong>Training focus:</strong> ${summary.nextTrainingFocus.join(" ")}</p>
  `;
}

async function refreshDocuments() {
  const documents = await api("/api/documents");
  renderList(
    $("#documents"),
    documents,
    (doc) => {
      const div = document.createElement("div");
      div.className = "doc-item";
      div.innerHTML = `<strong></strong><p></p>`;
      div.querySelector("strong").textContent = doc.title;
      div.querySelector("p").textContent = `${doc.chunks} chunks indexed`;
      return div;
    },
    "No documents indexed."
  );
}

async function refreshSocialPosts() {
  const posts = await api("/api/social-posts");
  $("#socialStatus").textContent = `${posts.length} labeled social posts available`;
  renderList(
    $("#socialPosts"),
    posts,
    (post) => {
      const div = document.createElement("div");
      div.className = "doc-item social-post";
      const meta = `${post.source} | ${post.intent.replaceAll("_", " ")} | ${post.sentiment} | risk ${post.risk_score}`;
      div.innerHTML = `<strong></strong><p></p><small></small>`;
      div.querySelector("strong").textContent = meta;
      div.querySelector("p").textContent = post.content;
      div.querySelector("small").textContent = `Keywords: ${post.keywords.slice(0, 8).join(", ") || "none"}`;
      return div;
    },
    "No social posts imported yet."
  );
}

async function fetchSocialPosts(event) {
  event.preventDefault();
  const query = $("#xQuery").value.trim();
  if (!query) return;
  $("#socialStatus").textContent = "Fetching from X API...";
  try {
    const result = await api("/api/social-posts/fetch", {
      method: "POST",
      body: JSON.stringify({ query, maxResults: 10 }),
    });
    $("#socialStatus").textContent = `Imported ${result.imported} X posts`;
  } catch (error) {
    $("#socialStatus").textContent = "Live fetch needs X_BEARER_TOKEN. Use demo or manual import.";
  }
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function importDemoTweets() {
  const result = await api("/api/social-posts/import", {
    method: "POST",
    body: JSON.stringify({ demo: true }),
  });
  $("#socialStatus").textContent = `Imported ${result.imported} demo tweets`;
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function importSocialText(event) {
  event.preventDefault();
  const content = $("#socialContent").value.trim();
  if (!content) return;
  const result = await api("/api/social-posts/import", {
    method: "POST",
    body: JSON.stringify({ content, source: "manual" }),
  });
  $("#socialContent").value = "";
  $("#socialStatus").textContent = `Imported ${result.imported} manual posts`;
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function createTrainingSnapshot() {
  const snapshot = await api("/api/training-snapshots", {
    method: "POST",
    body: JSON.stringify({}),
  });
  $("#trainingSnapshot").innerHTML = `
    <strong>${snapshot.examples} labeled examples | ${snapshot.status.replaceAll("_", " ")}</strong>
    <p>Average risk: ${snapshot.averageRisk}. High-risk examples: ${snapshot.highRiskExamples}.</p>
    <p><strong>Intent distribution:</strong> ${formatDistribution(snapshot.intentDistribution)}</p>
    <p><strong>Sentiment distribution:</strong> ${formatDistribution(snapshot.sentimentDistribution)}</p>
  `;
}

function formatDistribution(value) {
  const entries = Object.entries(value || {});
  if (entries.length === 0) return "none";
  return entries.map(([key, count]) => `${key.replaceAll("_", " ")} ${count}`).join(", ");
}

function downloadReport(path) {
  window.location.href = path;
}

function openSessionReport() {
  if (!state.currentSessionId) return;
  window.open(`/api/reports/session.html?id=${encodeURIComponent(state.currentSessionId)}`, "_blank");
}

async function addDocument(event) {
  event.preventDefault();
  const title = $("#docTitle").value.trim();
  const content = $("#docContent").value.trim();
  if (!content) return;
  await api("/api/documents", {
    method: "POST",
    body: JSON.stringify({ title, content }),
  });
  $("#docTitle").value = "";
  $("#docContent").value = "";
  await refreshDocuments();
  await refreshAnalytics();
}

let analyticsChart = null;

async function refreshAnalytics() {
  const [analytics, settings] = await Promise.all([api("/api/analytics"), api("/api/settings")]);
  const cards = [
    ["Sessions", analytics.sessions],
    ["Messages", analytics.messages],
    ["Documents", analytics.documents],
    ["RAG vectors", analytics.ragVectors],
    ["Social posts", analytics.socialPosts],
    ["Max risk", analytics.maxRisk],
    ["Avg score", analytics.averageScore],
    ["Medium threshold", settings.riskThresholds.medium],
    ["High threshold", settings.riskThresholds.high],
    ["LLM mode", settings.llm.mode],
    ["LLM model", settings.llm.model],
  ];
  $("#analyticsCards").innerHTML = cards
    .map(([label, value]) => `<div><strong>${value}</strong><span>${label}</span></div>`)
    .join("");
  renderAnalyticsChart(analytics);
}

function renderAnalyticsChart(analytics) {
  const canvas = $("#analyticsChart");
  if (!canvas || typeof Chart === "undefined") return;
  const labels = ["Sessions", "Messages", "Documents", "RAG vectors", "Social posts"];
  const values = [
    analytics.sessions,
    analytics.messages,
    analytics.documents,
    analytics.ragVectors,
    analytics.socialPosts,
  ];
  if (analyticsChart) {
    analyticsChart.data.datasets[0].data = values;
    analyticsChart.update();
    return;
  }
  const ctx = canvas.getContext("2d");
  const gradient = ctx.createLinearGradient(0, 0, 0, 220);
  gradient.addColorStop(0, "rgba(6, 182, 212, 0.85)");
  gradient.addColorStop(1, "rgba(124, 58, 237, 0.85)");
  analyticsChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [
        {
          label: "Count",
          data: values,
          backgroundColor: gradient,
          borderRadius: 8,
          maxBarThickness: 46,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { display: false } },
        y: { beginAtZero: true, grid: { color: "#eef0f8" } },
      },
    },
  });
}

$("#newSessionBtn").addEventListener("click", createSession);
$("#endSessionBtn").addEventListener("click", endSession);
$("#messageForm").addEventListener("submit", sendMessage);
$("#repReplyForm").addEventListener("submit", sendRepresentativeReply);
$("#documentForm").addEventListener("submit", addDocument);
$("#socialFetchForm").addEventListener("submit", fetchSocialPosts);
$("#demoTweetsBtn").addEventListener("click", importDemoTweets);
$("#socialImportForm").addEventListener("submit", importSocialText);
$("#trainingSnapshotBtn").addEventListener("click", createTrainingSnapshot);
$("#analyticsCsvBtn").addEventListener("click", () => downloadReport("/api/reports/analytics.csv"));
$("#sessionsCsvBtn").addEventListener("click", () => downloadReport("/api/reports/sessions.csv"));
$("#sessionReportBtn").addEventListener("click", openSessionReport);
document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => {
    $("#messageInput").value = button.dataset.prompt;
    $("#messageInput").focus();
  });
});

function initPageNav() {
  const navLinks = Array.from(document.querySelectorAll("nav a[href^='#']"));
  const pageIds = navLinks.map((link) => link.getAttribute("href").slice(1));

  function showPage(targetId) {
    pageIds.forEach((id) => {
      const section = document.getElementById(id);
      if (section) section.hidden = id !== targetId;
    });
    navLinks.forEach((link) => {
      link.classList.toggle("active", link.getAttribute("href") === `#${targetId}`);
    });
    window.scrollTo({ top: 0, behavior: "auto" });
    if (targetId === "analytics") refreshAnalytics();
  }

  navLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      showPage(link.getAttribute("href").slice(1));
    });
  });

  showPage("conversation");
}

initPageNav();
boot();
