# Database

SQLite data is stored here:

```text
database/data/support_coach.db
```

Tables are created automatically by `backend/app.py` when the app starts.

