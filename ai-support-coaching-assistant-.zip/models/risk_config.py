DEFAULT_RISK_THRESHOLDS = {
    "medium": 40,
    "high": 70,
}


def risk_thresholds() -> dict[str, int]:
    import os

    medium = int(os.environ.get("RISK_MEDIUM_THRESHOLD", DEFAULT_RISK_THRESHOLDS["medium"]))
    high = int(os.environ.get("RISK_HIGH_THRESHOLD", DEFAULT_RISK_THRESHOLDS["high"]))
    medium = max(0, min(medium, 100))
    high = max(medium + 1, min(high, 100))
    return {"medium": medium, "high": high}
