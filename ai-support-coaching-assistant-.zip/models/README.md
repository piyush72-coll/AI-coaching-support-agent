# Models And Rules

This prototype uses lightweight local rules instead of external ML models:

- Keyword-based intent detection
- Word-list sentiment detection
- Rule-based escalation scoring
- Local RAG retrieval using deterministic embeddings in SQLite
- Optional OpenAI-compatible LLM enhancement

Thresholds are configurable through environment variables:

```powershell
$env:RISK_MEDIUM_THRESHOLD="40"
$env:RISK_HIGH_THRESHOLD="70"
```

LLM environment variables:

```powershell
$env:OPENAI_API_KEY="your_api_key"
$env:LLM_PROVIDER="openai"
$env:LLM_MODEL="gpt-4o-mini"
$env:LLM_ENABLED="true"
```

System prompts are stored in `models/system_prompts.py`.
