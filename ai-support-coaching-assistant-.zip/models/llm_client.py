from __future__ import annotations

import json
import os
from typing import Any
from urllib.request import Request, urlopen


DEFAULT_LLM_MODEL = "gpt-4o-mini"


def llm_settings() -> dict[str, Any]:
    provider = os.environ.get("LLM_PROVIDER", "openai").strip().lower()
    model = os.environ.get("LLM_MODEL", DEFAULT_LLM_MODEL).strip() or DEFAULT_LLM_MODEL
    enabled = os.environ.get("LLM_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    has_key = bool(os.environ.get("OPENAI_API_KEY", "").strip())
    return {
        "provider": provider,
        "model": model,
        "enabled": enabled,
        "hasApiKey": has_key,
        "mode": "llm" if enabled and has_key else "rules_fallback",
    }


def generate_json(system_prompt: str, user_payload: dict[str, Any]) -> dict[str, Any] | None:
    settings = llm_settings()
    if settings["provider"] != "openai" or not settings["enabled"] or not settings["hasApiKey"]:
        return None

    body = {
        "model": settings["model"],
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    "Return only JSON. Input:\n"
                    + json.dumps(user_payload, ensure_ascii=True, indent=2)
                ),
            },
        ],
    }
    request = Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {os.environ['OPENAI_API_KEY'].strip()}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urlopen(request, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        content = data["choices"][0]["message"]["content"]
        return json.loads(content)
    except Exception:
        return None

