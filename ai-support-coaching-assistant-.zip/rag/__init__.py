"""Local RAG pipeline for document chunk indexing and retrieval."""

