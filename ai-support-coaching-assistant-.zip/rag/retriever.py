from __future__ import annotations

import json
import sqlite3
from typing import Any

from rag.embeddings import cosine_similarity, embed_text, tokenize


STOP_WORDS = {
    "a",
    "an",
    "and",
    "are",
    "be",
    "can",
    "for",
    "i",
    "is",
    "need",
    "of",
    "or",
    "the",
    "this",
    "to",
    "was",
    "with",
}


def normalize_term(term: str) -> str:
    if term.endswith("ies") and len(term) > 5:
        return term[:-3] + "y"
    if term.endswith("ed") and len(term) > 5:
        return term[:-2]
    if term.endswith("es") and len(term) > 5:
        return term[:-2]
    if term.endswith("s") and len(term) > 4:
        return term[:-1]
    return term


def keyword_overlap(query: str, content: str) -> int:
    query_terms = {normalize_term(term) for term in tokenize(query) if term not in STOP_WORDS}
    content_terms = {normalize_term(term) for term in tokenize(content) if term not in STOP_WORDS}
    return len(query_terms & content_terms)


def index_chunk(conn: sqlite3.Connection, chunk_id: str, content: str) -> None:
    embedding = embed_text(content)
    conn.execute(
        """
        INSERT INTO rag_vectors (chunk_id, embedding, updated_at)
        VALUES (?, ?, datetime('now'))
        ON CONFLICT(chunk_id) DO UPDATE SET
            embedding = excluded.embedding,
            updated_at = excluded.updated_at
        """,
        (chunk_id, json.dumps(embedding)),
    )


def backfill_index(conn: sqlite3.Connection) -> None:
    rows = conn.execute(
        """
        SELECT kc.id, kc.content
        FROM knowledge_chunks kc
        LEFT JOIN rag_vectors rv ON rv.chunk_id = kc.id
        WHERE rv.chunk_id IS NULL
        """
    ).fetchall()
    for row in rows:
        index_chunk(conn, row["id"], row["content"])


def retrieve_relevant_chunks(conn: sqlite3.Connection, query: str, limit: int = 3) -> list[dict[str, Any]]:
    query_embedding = embed_text(query)
    rows = conn.execute(
        """
        SELECT kc.id, kd.title, kc.content, kc.keywords, rv.embedding
        FROM knowledge_chunks kc
        JOIN knowledge_documents kd ON kd.id = kc.document_id
        LEFT JOIN rag_vectors rv ON rv.chunk_id = kc.id
        """
    ).fetchall()

    scored = []
    for row in rows:
        if row["embedding"]:
            chunk_embedding = json.loads(row["embedding"])
        else:
            chunk_embedding = embed_text(row["content"])
            index_chunk(conn, row["id"], row["content"])
        vector_score = cosine_similarity(query_embedding, chunk_embedding)
        overlap = keyword_overlap(query, f"{row['title']} {row['content']}")
        combined_score = vector_score + (overlap * 0.25)
        if combined_score > 0:
            scored.append(
                {
                    "id": row["id"],
                    "title": row["title"],
                    "content": row["content"],
                    "score": round(combined_score, 4),
                    "vectorScore": round(vector_score, 4),
                    "keywordOverlap": overlap,
                    "retrievalMode": "local_vector_rag",
                }
            )
    return sorted(scored, key=lambda item: item["score"], reverse=True)[:limit]
