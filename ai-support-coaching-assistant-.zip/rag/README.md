# RAG Pipeline

This folder contains the local retrieval-augmented generation layer.

Flow:

```text
Document text -> chunks -> local embeddings -> SQLite rag_vectors -> top chunks -> orchestrator/LLM
```

Files:

- `embeddings.py` - deterministic local text embeddings
- `retriever.py` - vector indexing, backfill, and retrieval

The local embedding implementation avoids external dependencies so the app runs offline. You can later replace `embed_text()` with OpenAI embeddings or ChromaDB/FAISS without changing the agent API.

