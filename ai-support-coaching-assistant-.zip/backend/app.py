from __future__ import annotations

import json
import os
import sqlite3
import time
import uuid
from csv import DictWriter
from datetime import datetime, timezone
from html import escape
from io import StringIO
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from agents.orchestrator import run_orchestrator
from agents.social_agents import DEMO_TWEETS, build_training_snapshot, fetch_x_posts, save_social_post
from agents.support_agents import (
    SIMULATED_CUSTOMERS,
    detect_intent,
    detect_sentiment,
    keywords_for,
    risk_level,
    session_summary,
)
from models.llm_client import llm_settings
from models.risk_config import risk_thresholds
from models.system_prompts import (
    ESCALATION_SYSTEM_PROMPT,
    INTENT_SENTIMENT_SYSTEM_PROMPT,
    KNOWLEDGE_RECOMMENDATION_SYSTEM_PROMPT,
    RESPONSE_SUGGESTION_SYSTEM_PROMPT,
    SUPPORT_COACH_SYSTEM_PROMPT,
)
from rag.retriever import backfill_index, index_chunk
from backend.simple_pdf import build_session_summary_pdf


PROJECT_ROOT = Path(__file__).resolve().parent.parent
ROOT = PROJECT_ROOT
PUBLIC_DIR = PROJECT_ROOT / "frontend" / "public"
DATA_DIR = PROJECT_ROOT / "database" / "data"
DB_PATH = DATA_DIR / "support_coach.db"

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def db() -> sqlite3.Connection:
    DATA_DIR.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                sender TEXT NOT NULL,
                content TEXT NOT NULL,
                sentiment TEXT NOT NULL DEFAULT 'neutral',
                intent TEXT NOT NULL DEFAULT 'general_support',
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id)
            );

            CREATE TABLE IF NOT EXISTS knowledge_documents (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS knowledge_chunks (
                id TEXT PRIMARY KEY,
                document_id TEXT NOT NULL,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL,
                keywords TEXT NOT NULL,
                FOREIGN KEY (document_id) REFERENCES knowledge_documents(id)
            );

            CREATE TABLE IF NOT EXISTS rag_vectors (
                chunk_id TEXT PRIMARY KEY,
                embedding TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (chunk_id) REFERENCES knowledge_chunks(id)
            );

            CREATE TABLE IF NOT EXISTS agent_events (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id)
            );

            CREATE TABLE IF NOT EXISTS summaries (
                id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL UNIQUE,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id)
            );

            CREATE TABLE IF NOT EXISTS social_posts (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                external_id TEXT,
                author_id TEXT,
                content TEXT NOT NULL,
                language TEXT NOT NULL DEFAULT 'unknown',
                intent TEXT NOT NULL,
                sentiment TEXT NOT NULL,
                risk_score INTEGER NOT NULL,
                keywords TEXT NOT NULL,
                raw_payload TEXT,
                posted_at TEXT,
                created_at TEXT NOT NULL,
                UNIQUE(source, external_id)
            );

            CREATE TABLE IF NOT EXISTS social_ingestion_runs (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                query TEXT NOT NULL,
                status TEXT NOT NULL,
                imported_count INTEGER NOT NULL,
                error TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS training_snapshots (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                payload TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )

        count = conn.execute("SELECT COUNT(*) AS count FROM knowledge_documents").fetchone()["count"]
        if count == 0:
            seed_knowledge(conn)
        backfill_index(conn)


def seed_knowledge(conn: sqlite3.Connection) -> None:
    docs = {
        "Refund Policy": (
            "Refunds can be issued for duplicate charges, failed service delivery, or cancellation "
            "within the eligible window. Always acknowledge the customer concern, verify account "
            "ownership, confirm the transaction date, and explain the expected refund timeline."
        ),
        "Escalation Playbook": (
            "Escalate when the customer asks for a manager, threatens churn, mentions legal action, "
            "reports repeated failed contacts, or uses strongly negative language. Before escalating, "
            "summarize the issue, apologize without blame, and share the next concrete action."
        ),
        "Technical Login Help": (
            "For login issues, verify email address, check recent password reset attempts, clear active "
            "sessions, and recommend cache clearing or a private browser window. Never ask for the "
            "customer password."
        ),
        "Delivery Issue Guide": (
            "For missing deliveries, confirm tracking status, shipping address, delivery photo, carrier "
            "notes, and eligible replacement or refund options. Keep the customer updated with a clear "
            "case owner and timeline."
        ),
    }
    for title, content in docs.items():
        add_document(conn, title, content)


def chunk_text(text: str, max_words: int = 90) -> list[str]:
    words = text.split()
    if not words:
        return []
    return [" ".join(words[i : i + max_words]) for i in range(0, len(words), max_words)]


def add_document(conn: sqlite3.Connection, title: str, content: str) -> str:
    doc_id = str(uuid.uuid4())
    conn.execute(
        "INSERT INTO knowledge_documents (id, title, content, created_at) VALUES (?, ?, ?, ?)",
        (doc_id, title, content, utc_now()),
    )
    for index, chunk in enumerate(chunk_text(content)):
        chunk_id = str(uuid.uuid4())
        conn.execute(
            """
            INSERT INTO knowledge_chunks (id, document_id, chunk_index, content, keywords)
            VALUES (?, ?, ?, ?, ?)
            """,
            (chunk_id, doc_id, index, chunk, json.dumps(sorted(keywords_for(chunk)))),
        )
        index_chunk(conn, chunk_id, chunk)
    return doc_id


def analytics_metrics(conn: sqlite3.Connection) -> dict[str, int]:
    sessions = conn.execute("SELECT COUNT(*) AS count FROM sessions").fetchone()["count"]
    messages = conn.execute("SELECT COUNT(*) AS count FROM messages").fetchone()["count"]
    docs = conn.execute("SELECT COUNT(*) AS count FROM knowledge_documents").fetchone()["count"]
    rag_vectors = conn.execute("SELECT COUNT(*) AS count FROM rag_vectors").fetchone()["count"]
    social_posts = conn.execute("SELECT COUNT(*) AS count FROM social_posts").fetchone()["count"]
    risks = conn.execute("SELECT payload FROM agent_events WHERE agent_name = 'Escalation Risk Monitor Agent'").fetchall()
    max_risk = max([json.loads(row["payload"]).get("riskScore", 0) for row in risks] or [0])
    summaries = conn.execute("SELECT payload FROM summaries").fetchall()
    avg_score = 0
    if summaries:
        avg_score = round(sum(json.loads(row["payload"]).get("score", 0) for row in summaries) / len(summaries))
    return {
        "sessions": sessions,
        "messages": messages,
        "documents": docs,
        "ragVectors": rag_vectors,
        "socialPosts": social_posts,
        "maxRisk": max_risk,
        "averageScore": avg_score,
    }


def build_session_report_html(
    session: dict[str, Any],
    messages: list[dict[str, Any]],
    events: list[dict[str, Any]],
    summary: dict[str, Any] | None,
) -> str:
    message_rows = "".join(
        (
            "<tr>"
            f"<td>{escape(row['created_at'])}</td>"
            f"<td>{escape(row['sender'])}</td>"
            f"<td>{escape(row['intent']).replace('_', ' ')}</td>"
            f"<td>{escape(row['sentiment'])}</td>"
            f"<td>{escape(row['content'])}</td>"
            "</tr>"
        )
        for row in messages
    )
    event_rows = ""
    for row in events:
        payload = json.loads(row["payload"])
        preview = json.dumps(payload, ensure_ascii=True)[:500]
        event_rows += (
            "<tr>"
            f"<td>{escape(row['created_at'])}</td>"
            f"<td>{escape(row['agent_name'])}</td>"
            f"<td>{escape(preview)}</td>"
            "</tr>"
        )

    summary_html = "<p>No post-interaction summary created yet.</p>"
    if summary:
        focus = ", ".join(summary.get("nextTrainingFocus", []))
        summary_html = (
            f"<p><strong>Score:</strong> {escape(str(summary.get('score', '-')))}</p>"
            f"<p><strong>Primary intent:</strong> {escape(str(summary.get('primaryIntent', '-'))).replace('_', ' ')}</p>"
            f"<p><strong>Summary:</strong> {escape(str(summary.get('summary', '-')))}</p>"
            f"<p><strong>Training focus:</strong> {escape(focus)}</p>"
        )

    return f"""<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Support Session Report</title>
    <style>
      body {{ font-family: Arial, sans-serif; color: #111827; margin: 32px; }}
      h1, h2 {{ margin-bottom: 8px; }}
      .meta, .card {{ border: 1px solid #d0d8e8; border-radius: 8px; padding: 14px; margin: 14px 0; }}
      table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
      th, td {{ border: 1px solid #d0d8e8; padding: 8px; text-align: left; vertical-align: top; }}
      th {{ background: #eef3f8; }}
      td {{ font-size: 13px; }}
      @media print {{ button {{ display: none; }} body {{ margin: 18px; }} }}
    </style>
  </head>
  <body>
    <button onclick="window.print()">Print / Save as PDF</button>
    <h1>Support Session Report</h1>
    <section class="meta">
      <p><strong>Session:</strong> {escape(session['title'])}</p>
      <p><strong>Status:</strong> {escape(session['status'])}</p>
      <p><strong>Created:</strong> {escape(session['created_at'])}</p>
      <p><strong>Updated:</strong> {escape(session['updated_at'])}</p>
    </section>
    <section class="card">
      <h2>Post Interaction Summary</h2>
      {summary_html}
    </section>
    <section class="card">
      <h2>Conversation</h2>
      <table>
        <thead><tr><th>Time</th><th>Sender</th><th>Intent</th><th>Sentiment</th><th>Message</th></tr></thead>
        <tbody>{message_rows}</tbody>
      </table>
    </section>
    <section class="card">
      <h2>Agent Events</h2>
      <table>
        <thead><tr><th>Time</th><th>Agent</th><th>Payload Preview</th></tr></thead>
        <tbody>{event_rows}</tbody>
      </table>
    </section>
  </body>
</html>"""


class ApiHandler(SimpleHTTPRequestHandler):
    server_version = "SupportCoach/1.0"

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, directory=str(PUBLIC_DIR), **kwargs)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            self.send_json({"ok": True, "time": utc_now()})
            return
        if parsed.path == "/api/settings":
            self.send_json({"riskThresholds": risk_thresholds(), "llm": llm_settings()})
            return
        if parsed.path == "/api/system-prompts":
            self.send_json(
                {
                    "supportCoach": SUPPORT_COACH_SYSTEM_PROMPT,
                    "intentSentiment": INTENT_SENTIMENT_SYSTEM_PROMPT,
                    "knowledgeRecommendation": KNOWLEDGE_RECOMMENDATION_SYSTEM_PROMPT,
                    "responseSuggestion": RESPONSE_SUGGESTION_SYSTEM_PROMPT,
                    "escalation": ESCALATION_SYSTEM_PROMPT,
                }
            )
            return
        if parsed.path == "/api/sample-questions":
            self.send_json({"questions": SIMULATED_CUSTOMERS})
            return
        if parsed.path == "/api/sessions":
            self.list_sessions()
            return
        if parsed.path.startswith("/api/sessions/"):
            self.get_session(parsed.path.split("/")[-1])
            return
        if parsed.path == "/api/documents":
            self.list_documents()
            return
        if parsed.path == "/api/social-posts":
            self.list_social_posts()
            return
        if parsed.path == "/api/training-snapshots":
            self.list_training_snapshots()
            return
        if parsed.path == "/api/analytics":
            self.analytics()
            return
        if parsed.path == "/api/reports/analytics.csv":
            self.analytics_csv_report()
            return
        if parsed.path == "/api/reports/sessions.csv":
            self.sessions_csv_report()
            return
        if parsed.path == "/api/reports/session.html":
            self.session_html_report(parse_qs(parsed.query).get("id", [""])[0])
            return
        if parsed.path == "/api/reports/session.pdf":
            self.session_pdf_report(parse_qs(parsed.query).get("id", [""])[0])
            return
        return super().do_GET()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/sessions":
            self.create_session()
            return
        if parsed.path.endswith("/messages") and parsed.path.startswith("/api/sessions/"):
            session_id = parsed.path.split("/")[-2]
            self.add_message(session_id)
            return
        if parsed.path.endswith("/simulate") and parsed.path.startswith("/api/sessions/"):
            session_id = parsed.path.split("/")[-2]
            self.simulate_customer(session_id)
            return
        if parsed.path.endswith("/summary") and parsed.path.startswith("/api/sessions/"):
            session_id = parsed.path.split("/")[-2]
            self.create_summary(session_id)
            return
        if parsed.path == "/api/documents":
            self.create_document()
            return
        if parsed.path == "/api/social-posts/import":
            self.import_social_posts()
            return
        if parsed.path == "/api/social-posts/fetch":
            self.fetch_social_posts()
            return
        if parsed.path == "/api/training-snapshots":
            self.create_training_snapshot()
            return
        self.send_error(404)

    def read_json(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length == 0:
            return {}
        body = self.rfile.read(length).decode("utf-8")
        return json.loads(body)

    def send_json(self, payload: Any, status: int = 200) -> None:
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_download(self, payload: str, filename: str, content_type: str) -> None:
        data = payload.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_binary_download(self, data: bytes, filename: str, content_type: str) -> None:
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def list_sessions(self) -> None:
        with db() as conn:
            rows = conn.execute("SELECT * FROM sessions ORDER BY updated_at DESC").fetchall()
            self.send_json([dict(row) for row in rows])

    def create_session(self) -> None:
        payload = self.read_json()
        session_id = str(uuid.uuid4())
        title = payload.get("title") or f"Coaching Session {datetime.now().strftime('%H:%M')}"
        now = utc_now()
        with db() as conn:
            conn.execute(
                "INSERT INTO sessions (id, title, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (session_id, title, "active", now, now),
            )
        self.send_json({"id": session_id, "title": title, "status": "active", "created_at": now, "updated_at": now}, 201)

    def get_session(self, session_id: str) -> None:
        with db() as conn:
            session = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
            if not session:
                self.send_error(404)
                return
            messages = conn.execute(
                "SELECT * FROM messages WHERE session_id = ? ORDER BY created_at", (session_id,)
            ).fetchall()
            events = conn.execute(
                "SELECT * FROM agent_events WHERE session_id = ? ORDER BY created_at DESC LIMIT 20",
                (session_id,),
            ).fetchall()
            summary = conn.execute("SELECT payload FROM summaries WHERE session_id = ?", (session_id,)).fetchone()
            self.send_json(
                {
                    "session": dict(session),
                    "messages": [dict(row) for row in messages],
                    "events": [{**dict(row), "payload": json.loads(row["payload"])} for row in events],
                    "summary": json.loads(summary["payload"]) if summary else None,
                }
            )

    def add_message(self, session_id: str) -> None:
        payload = self.read_json()
        content = (payload.get("content") or "").strip()
        sender = (payload.get("sender") or "customer").strip().lower()
        if sender not in {"customer", "agent"}:
            sender = "customer"
        if not content:
            self.send_json({"error": "Message content is required."}, 400)
            return
        with db() as conn:
            if not conn.execute("SELECT 1 FROM sessions WHERE id = ?", (session_id,)).fetchone():
                self.send_error(404)
                return
            if sender == "agent":
                message = {
                    "id": str(uuid.uuid4()),
                    "session_id": session_id,
                    "sender": "agent",
                    "content": content,
                    "sentiment": "neutral",
                    "intent": "representative_reply",
                    "created_at": utc_now(),
                }
                conn.execute(
                    """
                    INSERT INTO messages (id, session_id, sender, content, sentiment, intent, created_at)
                    VALUES (:id, :session_id, :sender, :content, :sentiment, :intent, :created_at)
                    """,
                    message,
                )
                conn.execute(
                    "UPDATE sessions SET status = ?, updated_at = ? WHERE id = ?",
                    ("active", utc_now(), session_id),
                )
                self.send_json({"message": message, "agentOutput": None}, 201)
                return
            sentiment, _score = detect_sentiment(content)
            intent = detect_intent(content)
            message = {
                "id": str(uuid.uuid4()),
                "session_id": session_id,
                "sender": sender,
                "content": content,
                "sentiment": sentiment if sender == "customer" else "neutral",
                "intent": intent if sender == "customer" else "agent_response",
                "created_at": utc_now(),
            }
            conn.execute(
                """
                INSERT INTO messages (id, session_id, sender, content, sentiment, intent, created_at)
                VALUES (:id, :session_id, :sender, :content, :sentiment, :intent, :created_at)
                """,
                message,
            )
            conn.execute("UPDATE sessions SET updated_at = ? WHERE id = ?", (utc_now(), session_id))
            agent_output = run_orchestrator(conn, session_id, content)
            if agent_output:
                solution = agent_output.get("preciseSolution", {})
                resolution = agent_output.get("customerResolution", {})
                is_handoff = bool(agent_output.get("transferToLiveAgent"))
                if is_handoff:
                    ai_content = resolution.get("answer") or (
                        "I understand this needs urgent attention. I am transferring this chat "
                        "to a live support representative now."
                    )
                else:
                    ai_content = resolution.get("answer") or solution.get("answer") or (
                        "I found the relevant support guidance and will help resolve this."
                    )
                ai_message = {
                    "id": str(uuid.uuid4()),
                    "session_id": session_id,
                    "sender": "ai",
                    "content": ai_content,
                    "sentiment": "neutral",
                    "intent": "live_agent_handoff" if is_handoff else "ai_customer_resolution",
                    "created_at": utc_now(),
                }
                conn.execute(
                    """
                    INSERT INTO messages (id, session_id, sender, content, sentiment, intent, created_at)
                    VALUES (:id, :session_id, :sender, :content, :sentiment, :intent, :created_at)
                    """,
                    ai_message,
                )
            if agent_output and agent_output.get("transferToLiveAgent"):
                conn.execute("UPDATE sessions SET status = ?, updated_at = ? WHERE id = ?", ("needs_human", utc_now(), session_id))
                conn.execute(
                    """
                    INSERT INTO agent_events (id, session_id, agent_name, payload, created_at)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        str(uuid.uuid4()),
                        session_id,
                        "Live Agent Transfer Agent",
                        json.dumps(
                            {
                                "status": agent_output["liveAgentStatus"],
                                "reason": agent_output["liveAgentReason"],
                            }
                        ),
                        utc_now(),
                    ),
                )
        self.send_json({"message": message, "agentOutput": agent_output}, 201)

    def simulate_customer(self, session_id: str) -> None:
        payload = self.read_json()
        index = int(time.time()) % len(SIMULATED_CUSTOMERS)
        content = payload.get("content") or SIMULATED_CUSTOMERS[index]
        self.path = f"/api/sessions/{session_id}/messages"
        self.headers.replace_header("Content-Length", str(len(json.dumps({"sender": "customer", "content": content}))))
        body = json.dumps({"sender": "customer", "content": content}).encode("utf-8")
        self.rfile = MemoryReader(body)
        self.add_message(session_id)

    def create_summary(self, session_id: str) -> None:
        with db() as conn:
            if not conn.execute("SELECT 1 FROM sessions WHERE id = ?", (session_id,)).fetchone():
                self.send_error(404)
                return
            summary = session_summary(conn, session_id)
            conn.execute("UPDATE sessions SET status = ?, updated_at = ? WHERE id = ?", ("complete", utc_now(), session_id))
        self.send_json(summary, 201)

    def list_documents(self) -> None:
        with db() as conn:
            rows = conn.execute(
                """
                SELECT kd.id, kd.title, kd.created_at, COUNT(kc.id) AS chunks
                FROM knowledge_documents kd
                LEFT JOIN knowledge_chunks kc ON kc.document_id = kd.id
                GROUP BY kd.id
                ORDER BY kd.created_at DESC
                """
            ).fetchall()
        self.send_json([dict(row) for row in rows])

    def create_document(self) -> None:
        payload = self.read_json()
        title = (payload.get("title") or "Untitled Document").strip()
        content = (payload.get("content") or "").strip()
        if not content:
            self.send_json({"error": "Document content is required."}, 400)
            return
        with db() as conn:
            doc_id = add_document(conn, title, content)
        self.send_json({"id": doc_id, "title": title}, 201)

    def list_social_posts(self) -> None:
        with db() as conn:
            rows = conn.execute(
                """
                SELECT id, source, external_id, content, language, intent, sentiment, risk_score, keywords, posted_at, created_at
                FROM social_posts
                ORDER BY created_at DESC
                LIMIT 100
                """
            ).fetchall()
        posts = []
        for row in rows:
            item = dict(row)
            item["keywords"] = json.loads(item["keywords"])
            item["riskLevel"] = risk_level(item["risk_score"])
            posts.append(item)
        self.send_json(posts)

    def import_social_posts(self) -> None:
        payload = self.read_json()
        source = payload.get("source") or "manual"
        language = payload.get("language") or "en"
        texts = payload.get("texts")
        if not texts:
            content = payload.get("content") or ""
            texts = [line.strip() for line in content.splitlines() if line.strip()]
        if payload.get("demo"):
            texts = DEMO_TWEETS
            source = "demo_x"
        if not texts:
            self.send_json({"error": "Provide social post text or enable demo import."}, 400)
            return

        imported = []
        with db() as conn:
            for text in texts:
                imported.append(save_social_post(conn, source=source, content=text, language=language))
            conn.execute(
                """
                INSERT INTO social_ingestion_runs (id, source, query, status, imported_count, error, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (str(uuid.uuid4()), source, "manual_import", "complete", len(imported), None, utc_now()),
            )
        self.send_json({"imported": len(imported), "posts": imported}, 201)

    def fetch_social_posts(self) -> None:
        payload = self.read_json()
        query = (payload.get("query") or "").strip()
        max_results = int(payload.get("maxResults") or 10)
        if not query:
            self.send_json({"error": "Query is required."}, 400)
            return

        run_id = str(uuid.uuid4())
        try:
            fetched = fetch_x_posts(query, max_results)
            imported = []
            with db() as conn:
                for post in fetched:
                    imported.append(
                        save_social_post(
                            conn,
                            source="x_api",
                            external_id=post.get("id"),
                            author_id=post.get("author_id"),
                            content=post.get("text", ""),
                            language=post.get("lang") or "unknown",
                            raw_payload=post,
                            posted_at=post.get("created_at"),
                        )
                    )
                conn.execute(
                    """
                    INSERT INTO social_ingestion_runs (id, source, query, status, imported_count, error, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (run_id, "x_api", query, "complete", len(imported), None, utc_now()),
                )
            self.send_json({"imported": len(imported), "posts": imported}, 201)
        except Exception as exc:
            with db() as conn:
                conn.execute(
                    """
                    INSERT INTO social_ingestion_runs (id, source, query, status, imported_count, error, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (run_id, "x_api", query, "failed", 0, str(exc), utc_now()),
                )
            self.send_json({"error": str(exc), "runId": run_id}, 400)

    def list_training_snapshots(self) -> None:
        with db() as conn:
            rows = conn.execute(
                "SELECT id, source, payload, created_at FROM training_snapshots ORDER BY created_at DESC LIMIT 20"
            ).fetchall()
        self.send_json([{**dict(row), "payload": json.loads(row["payload"])} for row in rows])

    def create_training_snapshot(self) -> None:
        with db() as conn:
            snapshot = build_training_snapshot(conn)
        self.send_json(snapshot, 201)

    def analytics(self) -> None:
        with db() as conn:
            metrics = analytics_metrics(conn)
        self.send_json(metrics)

    def analytics_csv_report(self) -> None:
        with db() as conn:
            metrics = analytics_metrics(conn)
            intent_rows = conn.execute(
                """
                SELECT intent, COUNT(*) AS count
                FROM messages
                WHERE sender = 'customer'
                GROUP BY intent
                ORDER BY count DESC
                """
            ).fetchall()
            sentiment_rows = conn.execute(
                """
                SELECT sentiment, COUNT(*) AS count
                FROM messages
                WHERE sender = 'customer'
                GROUP BY sentiment
                ORDER BY count DESC
                """
            ).fetchall()

        output = StringIO()
        writer = DictWriter(output, fieldnames=["section", "metric", "value"])
        writer.writeheader()
        for metric, value in metrics.items():
            writer.writerow({"section": "analytics", "metric": metric, "value": value})
        for row in intent_rows:
            writer.writerow({"section": "intent_distribution", "metric": row["intent"], "value": row["count"]})
        for row in sentiment_rows:
            writer.writerow({"section": "sentiment_distribution", "metric": row["sentiment"], "value": row["count"]})
        self.send_download(output.getvalue(), "support_analytics_report.csv", "text/csv")

    def sessions_csv_report(self) -> None:
        with db() as conn:
            rows = conn.execute(
                """
                SELECT
                    s.id,
                    s.title,
                    s.status,
                    s.created_at,
                    s.updated_at,
                    COUNT(m.id) AS message_count,
                    SUM(CASE WHEN m.sender = 'customer' THEN 1 ELSE 0 END) AS customer_messages,
                    SUM(CASE WHEN m.sender = 'ai' THEN 1 ELSE 0 END) AS ai_messages
                FROM sessions s
                LEFT JOIN messages m ON m.session_id = s.id
                GROUP BY s.id
                ORDER BY s.updated_at DESC
                """
            ).fetchall()

        output = StringIO()
        writer = DictWriter(
            output,
            fieldnames=[
                "id",
                "title",
                "status",
                "created_at",
                "updated_at",
                "message_count",
                "customer_messages",
                "ai_messages",
            ],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(dict(row))
        self.send_download(output.getvalue(), "support_sessions_report.csv", "text/csv")

    def session_html_report(self, session_id: str) -> None:
        if not session_id:
            self.send_error(400, "Session id is required.")
            return
        with db() as conn:
            session = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
            if not session:
                self.send_error(404)
                return
            messages = conn.execute(
                "SELECT sender, content, sentiment, intent, created_at FROM messages WHERE session_id = ? ORDER BY created_at",
                (session_id,),
            ).fetchall()
            events = conn.execute(
                "SELECT agent_name, payload, created_at FROM agent_events WHERE session_id = ? ORDER BY created_at DESC LIMIT 30",
                (session_id,),
            ).fetchall()
            summary_row = conn.execute("SELECT payload, created_at FROM summaries WHERE session_id = ?", (session_id,)).fetchone()

        summary = json.loads(summary_row["payload"]) if summary_row else None
        html = build_session_report_html(dict(session), [dict(row) for row in messages], [dict(row) for row in events], summary)
        self.send_download(html, f"session_report_{session_id[:8]}.html", "text/html")

    def session_pdf_report(self, session_id: str) -> None:
        if not session_id:
            self.send_error(400, "Session id is required.")
            return
        with db() as conn:
            session = conn.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
            if not session:
                self.send_error(404)
                return
            messages = conn.execute(
                "SELECT sender, content FROM messages WHERE session_id = ? ORDER BY created_at",
                (session_id,),
            ).fetchall()
            summary_row = conn.execute(
                "SELECT payload FROM summaries WHERE session_id = ?", (session_id,)
            ).fetchone()
            summary = json.loads(summary_row["payload"]) if summary_row else None
            if summary is None:
                # A PDF is usually requested right after the customer confirms
                # the issue is resolved, so generate the summary on the fly
                # rather than forcing a second round trip from the client.
                summary = session_summary(conn, session_id)
                conn.execute(
                    "UPDATE sessions SET status = ?, updated_at = ? WHERE id = ?",
                    ("complete", utc_now(), session_id),
                )

        pdf_bytes = build_session_summary_pdf(dict(session), summary, [dict(row) for row in messages])
        self.send_binary_download(pdf_bytes, f"session_summary_{session_id[:8]}.pdf", "application/pdf")


class MemoryReader:
    def __init__(self, data: bytes) -> None:
        self.data = data
        self.offset = 0

    def read(self, length: int = -1) -> bytes:
        if length < 0:
            length = len(self.data) - self.offset
        chunk = self.data[self.offset : self.offset + length]
        self.offset += length
        return chunk


def main() -> None:
    init_db()
    host = os.environ.get("APP_HOST", "127.0.0.1")
    port = int(os.environ.get("APP_PORT", "8000"))
    server = ThreadingHTTPServer((host, port), ApiHandler)
    print(f"Support Coaching Assistant running at http://{host}:{port}")
    print(f"SQLite database: {DB_PATH}")
    server.serve_forever()


if __name__ == "__main__":
    main()
