"""Backend API package for the support coaching assistant."""
