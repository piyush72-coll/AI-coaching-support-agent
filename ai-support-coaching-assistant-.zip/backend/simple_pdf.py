"""A minimal, dependency-free PDF writer.

Only the Python standard library is used anywhere in this backend, so this
module hand-writes just enough of the PDF 1.4 object model (catalog, pages,
a single Helvetica font, and per-page text-drawing content streams) to lay
out a simple multi-page text report. It intentionally does not support
images, custom fonts, or rich layout - that is not needed for a session
summary export, and pulling in a third-party PDF library would break the
"stdlib only" backend constraint.
"""

from __future__ import annotations

import textwrap
from dataclasses import dataclass, field

PAGE_WIDTH = 612  # US Letter, in PDF points
PAGE_HEIGHT = 792
MARGIN = 54
LINE_HEIGHT = 15
WRAP_WIDTH = 92

_FONT_SIZES = {"title": 18, "heading": 13, "body": 10.5}


@dataclass
class PdfReport:
    """Accumulates styled text lines, then renders them to PDF bytes."""

    lines: list[tuple[str, str]] = field(default_factory=list)

    def title(self, text: str) -> "PdfReport":
        self.lines.append(("title", text))
        self.lines.append(("body", ""))
        return self

    def heading(self, text: str) -> "PdfReport":
        self.lines.append(("body", ""))
        self.lines.append(("heading", text))
        return self

    def body(self, text: str = "") -> "PdfReport":
        for wrapped in textwrap.wrap(text, width=WRAP_WIDTH) or [""]:
            self.lines.append(("body", wrapped))
        return self

    def render(self) -> bytes:
        pages = _paginate(self.lines)
        return _write_pdf(pages)


def _paginate(lines: list[tuple[str, str]]) -> list[list[tuple[str, str]]]:
    usable_height = PAGE_HEIGHT - 2 * MARGIN
    max_lines = max(1, int(usable_height / LINE_HEIGHT))
    pages: list[list[tuple[str, str]]] = []
    current: list[tuple[str, str]] = []
    for entry in lines:
        if len(current) >= max_lines:
            pages.append(current)
            current = []
        current.append(entry)
    pages.append(current or [("body", "")])
    return pages


def _pdf_escape(text: str) -> str:
    safe = text.encode("latin-1", errors="replace").decode("latin-1")
    return safe.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def _page_content_stream(page_lines: list[tuple[str, str]]) -> bytes:
    top = PAGE_HEIGHT - MARGIN
    ops = ["BT", f"{LINE_HEIGHT} TL", f"{MARGIN} {top} Td"]
    for index, (style, text) in enumerate(page_lines):
        if index > 0:
            ops.append("T*")
        ops.append(f"/F1 {_FONT_SIZES[style]} Tf")
        ops.append(f"({_pdf_escape(text)}) Tj")
    ops.append("ET")
    return "\n".join(ops).encode("latin-1", errors="replace")


def _write_pdf(pages: list[list[tuple[str, str]]]) -> bytes:
    catalog_num = 1
    pages_num = 2
    font_num = 3
    content_nums = [font_num + 1 + 2 * i for i in range(len(pages))]
    page_nums = [n + 1 for n in content_nums]

    objects: dict[int, bytes] = {}
    objects[catalog_num] = f"<< /Type /Catalog /Pages {pages_num} 0 R >>".encode("latin-1")
    kids = " ".join(f"{n} 0 R" for n in page_nums)
    objects[pages_num] = (
        f"<< /Type /Pages /Kids [{kids}] /Count {len(page_nums)} >>".encode("latin-1")
    )
    objects[font_num] = b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"

    for content_num, page_num, page_lines in zip(content_nums, page_nums, pages):
        stream = _page_content_stream(page_lines)
        objects[content_num] = (
            f"<< /Length {len(stream)} >>\nstream\n".encode("latin-1")
            + stream
            + b"\nendstream"
        )
        objects[page_num] = (
            f"<< /Type /Page /Parent {pages_num} 0 R "
            f"/MediaBox [0 0 {PAGE_WIDTH} {PAGE_HEIGHT}] "
            f"/Resources << /Font << /F1 {font_num} 0 R >> >> "
            f"/Contents {content_num} 0 R >>"
        ).encode("latin-1")

    out = bytearray(b"%PDF-1.4\n")
    offsets: dict[int, int] = {}
    for num in sorted(objects):
        offsets[num] = len(out)
        out += f"{num} 0 obj\n".encode("latin-1")
        out += objects[num]
        out += b"\nendobj\n"

    xref_start = len(out)
    total = len(objects)
    out += f"xref\n0 {total + 1}\n".encode("latin-1")
    out += b"0000000000 65535 f \n"
    for num in range(1, total + 1):
        out += f"{offsets[num]:010d} 00000 n \n".encode("latin-1")
    out += b"trailer\n"
    out += f"<< /Size {total + 1} /Root {catalog_num} 0 R >>\n".encode("latin-1")
    out += b"startxref\n"
    out += f"{xref_start}\n".encode("latin-1")
    out += b"%%EOF"
    return bytes(out)


def build_session_summary_pdf(
    session: dict,
    summary: dict | None,
    messages: list[dict],
) -> bytes:
    """Lay out a customer-facing session summary as a downloadable PDF."""
    report = PdfReport()
    report.title("Support Session Summary")
    report.body(f"Session: {session.get('title', 'Untitled session')}")
    report.body(f"Status: {session.get('status', '-')}")
    report.body(f"Created: {session.get('created_at', '-')}")
    report.body(f"Closed: {session.get('updated_at', '-')}")

    report.heading("Resolution summary")
    if summary:
        focus = ", ".join(summary.get("nextTrainingFocus", [])) or "-"
        report.body(f"Satisfaction score: {summary.get('score', '-')}/100")
        report.body(f"Primary topic: {str(summary.get('primaryIntent', '-')).replace('_', ' ')}")
        report.body(f"Peak escalation risk: {summary.get('maxEscalationRisk', '-')}")
        report.body(f"Messages exchanged: {summary.get('messageCount', '-')}")
        report.body(summary.get("summary", "-"))
        report.body(f"Follow-up focus: {focus}")
    else:
        report.body("No summary was generated for this session yet.")

    report.heading("Conversation transcript")
    role_labels = {"customer": "Customer", "ai": "AI Representative", "agent": "Representative"}
    for message in messages:
        who = role_labels.get(message.get("sender"), message.get("sender", "-"))
        report.body(f"{who}: {message.get('content', '')}")

    return report.render()
