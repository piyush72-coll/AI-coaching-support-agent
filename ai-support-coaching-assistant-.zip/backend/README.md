# Backend

The backend is a Python standard-library HTTP API in `backend/app.py`.

Run from the project root:

```powershell
python app.py
```

The root `app.py` file is a small launcher that calls `backend.app.main()`.

The backend imports agent behavior from `agents/` and LLM/system-prompt configuration from `models/`.
