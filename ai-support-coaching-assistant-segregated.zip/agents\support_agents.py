from __future__ import annotations

import json
import re
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from models.risk_config import risk_thresholds
from rag.retriever import retrieve_relevant_chunks


POSITIVE_WORDS = {
    "thanks",
    "thank",
    "great",
    "good",
    "helpful",
    "resolved",
    "perfect",
    "awesome",
    "appreciate",
    "clear",
}

NEGATIVE_WORDS = {
    "angry",
    "bad",
    "broken",
    "cancel",
    "complaint",
    "confused",
    "disappointed",
    "frustrated",
    "hate",
    "late",
    "never",
    "nobody",
    "nothing",
    "refund",
    "slow",
    "still",
    "terrible",
    "tired",
    "upset",
    "waiting",
    "wrong",
    "unacceptable",
    "manager",
    "escalate",
    "escalated",
}

INTENT_KEYWORDS = {
    "refund_request": {"refund", "money", "charged", "billing", "cancel"},
    "technical_support": {"broken", "error", "bug", "login", "password", "crash", "issue"},
    "shipping_status": {"shipping", "delivery", "late", "tracking", "package", "order"},
    "account_change": {"account", "email", "plan", "subscription", "upgrade", "downgrade"},
    "complaint": {"complaint", "angry", "manager", "unacceptable", "terrible"},
}

SIMULATED_CUSTOMERS = [
    "I was charged twice this month and I need a refund right now.",
    "My order says delivered, but nothing arrived at my address.",
    "I cannot log in after resetting my password three times.",
    "The agent yesterday promised a callback, and nobody contacted me.",
    "I want to cancel unless someone can fix this today.",
]


@dataclass
class AgentResult:
    name: str
    output: dict[str, Any]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", text.lower())


def keywords_for(text: str) -> set[str]:
    stop = {
        "the",
        "and",
        "for",
        "with",
        "that",
        "this",
        "you",
        "your",
        "can",
        "are",
        "from",
        "into",
        "when",
        "have",
        "has",
        "was",
        "were",
    }
    return {word for word in tokenize(text) if len(word) > 2 and word not in stop}


def detect_intent(text: str) -> str:
    words = set(tokenize(text))
    scores = {intent: len(words & terms) for intent, terms in INTENT_KEYWORDS.items()}
    best_intent, best_score = max(scores.items(), key=lambda item: item[1])
    return best_intent if best_score else "general_support"


def detect_sentiment(text: str) -> tuple[str, int]:
    words = set(tokenize(text))
    score = len(words & POSITIVE_WORDS) - len(words & NEGATIVE_WORDS)
    if score <= -2:
        return "negative", score
    if score >= 2:
        return "positive", score
    return "neutral", score


def retrieve_knowledge(conn: sqlite3.Connection, query: str, limit: int = 3) -> list[dict[str, Any]]:
    return retrieve_relevant_chunks(conn, query, limit)


def prioritize_recommendations(intent: str, recommendations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    preferred_source = {
        "refund_request": "Refund Policy",
        "technical_support": "Technical Login Help",
        "shipping_status": "Delivery Issue Guide",
        "complaint": "Escalation Playbook",
    }.get(intent)
    if not preferred_source:
        return recommendations
    return sorted(
        recommendations,
        key=lambda item: 0 if item.get("title") == preferred_source else 1,
    )


def escalation_risk(text: str, sentiment: str, intent: str) -> int:
    lower = text.lower()
    score = 15
    if sentiment == "negative":
        score += 30
    if intent in {"complaint", "refund_request"}:
        score += 20
    if any(term in lower for term in ["manager", "legal", "cancel", "unacceptable", "escalate"]):
        score += 25
    if any(term in lower for term in ["again", "twice", "three times", "nobody", "still"]):
        score += 10
    return min(score, 100)


def risk_level(score: int) -> str:
    thresholds = risk_thresholds()
    if score >= thresholds["high"]:
        return "high"
    if score >= thresholds["medium"]:
        return "medium"
    return "low"


def escalation_alerts(score: int, text: str) -> list[str]:
    alerts = []
    thresholds = risk_thresholds()
    if score >= thresholds["high"]:
        alerts.append("High escalation risk: acknowledge urgency and offer a concrete next step.")
    elif score >= thresholds["medium"]:
        alerts.append("Medium escalation risk: slow down, validate the concern, and keep the next action concrete.")
    if "manager" in text.lower():
        alerts.append("Customer requested management attention.")
    if "cancel" in text.lower():
        alerts.append("Churn risk detected.")
    return alerts


def consolidate_customer_behavior(text: str, sentiment: str, intent: str, risk_score: int) -> dict[str, Any]:
    lower = text.lower()
    signals = []
    if sentiment == "negative":
        signals.append("frustrated or dissatisfied tone")
    if any(term in lower for term in ["again", "twice", "three times", "nobody", "still"]):
        signals.append("repeated-contact or unresolved-issue pattern")
    if any(term in lower for term in ["manager", "escalate", "legal"]):
        signals.append("explicit escalation request")
    if "cancel" in lower:
        signals.append("possible churn/cancellation risk")
    if not signals:
        signals.append("standard support request")

    if risk_score >= risk_thresholds()["high"]:
        engagement_style = "urgent handoff with calm acknowledgement"
    elif sentiment == "negative":
        engagement_style = "empathetic de-escalation before troubleshooting"
    else:
        engagement_style = "direct problem-solving with concise confirmation"

    return {
        "intent": intent,
        "sentiment": sentiment,
        "riskScore": risk_score,
        "signals": signals,
        "engagementStyle": engagement_style,
        "summary": (
            f"Customer appears to have a {intent.replace('_', ' ')} issue with {sentiment} sentiment. "
            f"Best approach: {engagement_style}."
        ),
    }


def build_precise_solution(
    intent: str,
    recommendations: list[dict[str, Any]],
    behavior_profile: dict[str, Any],
) -> dict[str, Any]:
    action_map = {
        "refund_request": [
            "Verify account ownership and duplicate transaction details.",
            "Confirm refund eligibility using the refund policy.",
            "Give a clear refund timeline or escalation path.",
        ],
        "technical_support": [
            "Confirm the affected account and exact error.",
            "Check reset attempts, active sessions, and browser/cache steps.",
            "Avoid asking for passwords and document the troubleshooting result.",
        ],
        "shipping_status": [
            "Confirm order number, tracking status, and shipping address.",
            "Check carrier notes and delivery evidence.",
            "Offer eligible replacement, refund, or case-owner follow-up.",
        ],
        "account_change": [
            "Verify account ownership.",
            "Confirm the requested plan/account change.",
            "Explain the impact and complete the change only after confirmation.",
        ],
        "complaint": [
            "Acknowledge the complaint without blame.",
            "Summarize the issue and previous failed contacts.",
            "Escalate or provide a concrete next action with ownership.",
        ],
    }
    steps = action_map.get(
        intent,
        [
            "Clarify the customer's exact issue.",
            "Match the issue to the most relevant knowledge article.",
            "Provide the next concrete support action.",
        ],
    )
    source = select_solution_source(intent, recommendations)
    return {
        "source": source,
        "steps": steps,
        "answer": (
            f"Use {source}. First acknowledge the customer's situation, then follow: "
            + " ".join(steps)
        ),
        "style": behavior_profile["engagementStyle"],
    }


def build_customer_resolution(
    intent: str,
    recommendations: list[dict[str, Any]],
    solution: dict[str, Any],
    risk_score: int,
) -> dict[str, Any]:
    source = solution.get("source") or "available support knowledge"
    steps = solution.get("steps", [])
    if risk_score >= risk_thresholds()["high"]:
        return {
            "answer": (
                "I understand this needs urgent attention. I am transferring this chat to a live "
                "support representative now so they can review the details and resolve it with priority."
            ),
            "visibleToCustomer": True,
            "source": source,
            "status": "handoff",
        }

    intro = {
        "refund_request": "I can help with the refund request.",
        "technical_support": "I can help troubleshoot the login or technical issue.",
        "shipping_status": "I can help check the delivery issue.",
        "account_change": "I can help with the account change request.",
        "complaint": "I understand the concern and I can help move this forward.",
    }.get(intent, "I can help with this support request.")
    detail = " ".join(steps)
    evidence = recommendations[0]["content"] if recommendations else "I need one more detail to match the right policy."
    return {
        "answer": f"{intro} Based on {source}: {detail} Reference: {evidence}",
        "visibleToCustomer": True,
        "source": source,
        "status": "resolved_by_ai",
    }


def build_representative_assist(
    customer_text: str,
    intent: str,
    behavior_profile: dict[str, Any],
    solution: dict[str, Any],
    coaching: list[str],
    risk_score: int,
) -> dict[str, Any]:
    should_take_over = risk_score >= risk_thresholds()["high"]
    source = solution.get("source") or "available support knowledge"
    draft = build_response_suggestion(customer_text, intent, behavior_profile["sentiment"], [{"title": source}], risk_score)
    if should_take_over:
        draft = (
            "I have the context. I will take over from here, verify the account and issue details, "
            f"then resolve it using {source}. {draft}"
        )
    return {
        "assignedTo": "human_representative" if should_take_over else "ai_assistant",
        "priority": "high" if should_take_over else risk_level(risk_score),
        "takeoverRequired": should_take_over,
        "draftReply": draft,
        "resolutionChecklist": solution.get("steps", []),
        "coachNotes": coaching,
        "customerSnapshot": behavior_profile["summary"],
    }


def select_solution_source(intent: str, recommendations: list[dict[str, Any]]) -> str:
    preferred_sources = {
        "refund_request": "Refund Policy",
        "technical_support": "Technical Login Help",
        "shipping_status": "Delivery Issue Guide",
        "complaint": "Escalation Playbook",
    }
    source_terms = {
        "refund_request": {"refund", "billing", "charge", "charged"},
        "technical_support": {"login", "password", "technical", "error"},
        "shipping_status": {"delivery", "shipping", "tracking", "package"},
        "account_change": {"account", "subscription", "plan", "email"},
        "complaint": {"escalation", "complaint", "manager"},
    }
    expected_terms = source_terms.get(intent, set())
    preferred = preferred_sources.get(intent)
    if preferred:
        for recommendation in recommendations:
            if recommendation.get("title") == preferred:
                return recommendation["title"]
    for recommendation in recommendations:
        haystack = f"{recommendation.get('title', '')} {recommendation.get('content', '')}".lower()
        if any(term in haystack for term in expected_terms):
            return recommendation["title"]
    if preferred:
        return preferred
    if recommendations:
        return recommendations[0]["title"]
    return "No matching knowledge article"


def build_coaching(
    text: str,
    intent: str,
    sentiment: str,
    recommendations: list[dict[str, Any]],
    risk_score: int,
) -> list[str]:
    coaching = [
        "Reflect the customer's issue in one sentence before troubleshooting.",
        "Ask one verification question at a time.",
    ]
    if sentiment == "negative":
        coaching.insert(0, "Lead with empathy and avoid policy-first language.")
    if intent == "refund_request":
        coaching.append("Confirm charge date and explain refund timing clearly.")
    if intent == "technical_support":
        coaching.append("Protect credentials: never request the customer's password.")
    if risk_score >= risk_thresholds()["high"]:
        coaching.append("Offer escalation or supervisor review after summarizing the case.")
    if recommendations:
        coaching.append(f"Use the '{recommendations[0]['title']}' knowledge article.")
    return coaching


def build_response_suggestion(
    text: str,
    intent: str,
    sentiment: str,
    recommendations: list[dict[str, Any]],
    risk_score: int,
) -> str:
    opener = "I understand how frustrating this is, and I can help take ownership of it."
    if sentiment != "negative":
        opener = "Thanks for sharing the details. I can help with that."

    intent_action = {
        "refund_request": "I will verify the charge and check refund eligibility and timeline.",
        "technical_support": "I will walk through the login checks and keep your account secure.",
        "shipping_status": "I will review the tracking details and confirm the best replacement or refund path.",
        "account_change": "I will review the account settings and confirm the safest way to update them.",
        "complaint": "I will summarize what happened and make sure the next step is clear.",
    }.get(intent, "I will review the details and guide you through the next best step.")

    knowledge = ""
    if recommendations:
        knowledge = f" Based on our {recommendations[0]['title'].lower()},"
    escalation = (
        " If you prefer, I can also involve a supervisor after I document the issue."
        if risk_score >= risk_thresholds()["high"]
        else ""
    )
    return f"{opener}{knowledge} {intent_action}{escalation}"


def run_agents(conn: sqlite3.Connection, session_id: str, customer_text: str) -> dict[str, Any]:
    intent = detect_intent(customer_text)
    sentiment, sentiment_score = detect_sentiment(customer_text)
    recommendations = prioritize_recommendations(intent, retrieve_knowledge(conn, customer_text))
    risk_score = escalation_risk(customer_text, sentiment, intent)
    behavior_profile = consolidate_customer_behavior(customer_text, sentiment, intent, risk_score)
    precise_solution = build_precise_solution(intent, recommendations, behavior_profile)
    coaching = build_coaching(customer_text, intent, sentiment, recommendations, risk_score)
    response = build_response_suggestion(customer_text, intent, sentiment, recommendations, risk_score)
    customer_resolution = build_customer_resolution(intent, recommendations, precise_solution, risk_score)
    representative_assist = build_representative_assist(
        customer_text,
        intent,
        behavior_profile,
        precise_solution,
        coaching,
        risk_score,
    )

    results = [
        AgentResult(
            "Intent & Sentiment Analysis Agent",
            {"intent": intent, "sentiment": sentiment, "sentimentScore": sentiment_score},
        ),
        AgentResult("Knowledge Recommendation Agent", {"recommendations": recommendations}),
        AgentResult("Customer Behavior Consolidation Agent", {"behaviorProfile": behavior_profile}),
        AgentResult("Coaching & Response Suggestion Agent", {"coaching": coaching, "response": response}),
        AgentResult("Precise Solution Agent", {"solution": precise_solution}),
        AgentResult("Customer Resolution Agent", {"resolution": customer_resolution}),
        AgentResult("Representative Assist Agent", {"assist": representative_assist}),
        AgentResult(
            "Escalation Risk Monitor Agent",
            {"riskScore": risk_score, "level": risk_level(risk_score), "alerts": escalation_alerts(risk_score, customer_text)},
        ),
    ]

    for result in results:
        conn.execute(
            """
            INSERT INTO agent_events (id, session_id, agent_name, payload, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (str(uuid.uuid4()), session_id, result.name, json.dumps(result.output), utc_now()),
        )

    return {
        "intent": intent,
        "sentiment": sentiment,
        "sentimentScore": sentiment_score,
        "recommendations": recommendations,
        "customerBehavior": behavior_profile,
        "preciseSolution": precise_solution,
        "customerResolution": customer_resolution,
        "representativeAssist": representative_assist,
        "riskScore": risk_score,
        "riskLevel": risk_level(risk_score),
        "alerts": escalation_alerts(risk_score, customer_text),
        "coaching": coaching,
        "suggestedResponse": response,
    }


def session_summary(conn: sqlite3.Connection, session_id: str) -> dict[str, Any]:
    messages = conn.execute(
        "SELECT sender, content, sentiment, intent FROM messages WHERE session_id = ? ORDER BY created_at",
        (session_id,),
    ).fetchall()
    customer_messages = [row for row in messages if row["sender"] == "customer"]
    intents = [row["intent"] for row in customer_messages]
    negatives = [row for row in customer_messages if row["sentiment"] == "negative"]
    events = conn.execute(
        "SELECT payload FROM agent_events WHERE session_id = ? AND agent_name = ?",
        (session_id, "Escalation Risk Monitor Agent"),
    ).fetchall()
    max_risk = 0
    for event in events:
        max_risk = max(max_risk, json.loads(event["payload"]).get("riskScore", 0))

    summary = {
        "messageCount": len(messages),
        "customerTurns": len(customer_messages),
        "primaryIntent": most_common(intents) or "general_support",
        "negativeTurns": len(negatives),
        "maxEscalationRisk": max_risk,
        "score": max(35, 100 - max_risk - len(negatives) * 5),
        "summary": build_plain_summary(customer_messages, max_risk),
        "nextTrainingFocus": training_focus(max_risk, len(negatives)),
    }
    conn.execute(
        """
        INSERT INTO summaries (id, session_id, payload, created_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(session_id) DO UPDATE SET payload = excluded.payload, created_at = excluded.created_at
        """,
        (str(uuid.uuid4()), session_id, json.dumps(summary), utc_now()),
    )
    return summary


def most_common(items: list[str]) -> str | None:
    if not items:
        return None
    return max(set(items), key=items.count)


def build_plain_summary(customer_messages: list[sqlite3.Row], max_risk: int) -> str:
    if not customer_messages:
        return "No customer turns were recorded."
    issue = customer_messages[-1]["content"]
    return f"Customer discussed: {issue[:180]}. Peak escalation risk was {risk_level(max_risk)}."


def training_focus(max_risk: int, negative_turns: int) -> list[str]:
    focus = ["Maintain concise summaries before proposing actions."]
    if max_risk >= risk_thresholds()["high"]:
        focus.append("Practice de-escalation and supervisor handoff language.")
    if negative_turns:
        focus.append("Use empathy statements before asking diagnostic questions.")
    return focus
