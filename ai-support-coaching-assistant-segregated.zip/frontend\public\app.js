const state = {
  sessions: [],
  currentSessionId: null,
  lastAgentOutput: null,
};

const $ = (selector) => document.querySelector(selector);

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function renderList(target, items, renderer, emptyText = "No data yet.") {
  target.innerHTML = "";
  if (!items || items.length === 0) {
    target.innerHTML = `<p class="muted">${emptyText}</p>`;
    return;
  }
  items.forEach((item) => target.appendChild(renderer(item)));
}

async function boot() {
  try {
    await api("/api/health");
    $("#healthStatus").textContent = "Backend online";
  } catch {
    $("#healthStatus").textContent = "Backend unavailable";
  }
  await refreshSessions();
  await refreshDocuments();
  await refreshSocialPosts();
  await refreshAnalytics();
  if (!state.currentSessionId) {
    await createSession();
  }
}

async function refreshSessions() {
  state.sessions = await api("/api/sessions");
  const list = $("#sessionList");
  renderList(
    list,
    state.sessions,
    (session) => {
      const button = document.createElement("button");
      button.className = `session-item ${session.status === "needs_human" ? "needs-human" : ""}`;
      button.textContent = session.status === "needs_human" ? `${session.title} - needs you` : session.title;
      button.onclick = () => loadSession(session.id);
      return button;
    },
    "No sessions yet."
  );
}

async function createSession() {
  const session = await api("/api/sessions", {
    method: "POST",
    body: JSON.stringify({ title: `Coaching Session ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` }),
  });
  state.currentSessionId = session.id;
  await refreshSessions();
  await loadSession(session.id);
}

async function loadSession(id) {
  state.currentSessionId = id;
  const data = await api(`/api/sessions/${id}`);
  $("#sessionTitle").textContent = data.session.title;
  renderMessages(data.messages);
  renderEvents(data.events);
  renderSummary(data.summary);
}

function renderMessages(messages) {
  const box = $("#messages");
  box.innerHTML = "";
  if (messages.length === 0) {
    box.innerHTML = `
      <div class="message ai">
        <strong>AI Support - greeting</strong>
        <span>Hello, I am ready. Enter the customer's query and I will fetch the matching resolution. If risk is high, I will transfer it to the representative with an AI draft.</span>
      </div>
    `;
    return;
  }
  messages.forEach((message) => {
    const div = document.createElement("div");
    const isAi = message.sender === "ai" || message.sender === "agent";
    const isHandoff = message.intent === "live_agent_handoff";
    const label = isHandoff ? "Transfer Notice" : isAi ? "AI Resolution" : "Customer";
    div.className = `message ${isHandoff ? "handoff" : isAi ? "ai" : "customer"}`;
    div.innerHTML = `<strong>${label} - ${message.intent.replaceAll("_", " ")}</strong><span></span>`;
    div.querySelector("span").textContent = message.content;
    box.appendChild(div);
  });
  box.scrollTop = box.scrollHeight;
}

function renderEvents(events) {
  const latest = events.find((event) => event.agent_name === "Escalation Risk Monitor Agent");
  const analysis = events.find((event) => event.agent_name === "Intent & Sentiment Analysis Agent");
  const knowledge = events.find((event) => event.agent_name === "Knowledge Recommendation Agent");
  const behavior = events.find((event) => event.agent_name === "Customer Behavior Consolidation Agent");
  const solution = events.find((event) => event.agent_name === "Precise Solution Agent");
  const customerResolution = events.find((event) => event.agent_name === "Customer Resolution Agent");
  const representativeAssist = events.find((event) => event.agent_name === "Representative Assist Agent");
  const coaching = events.find((event) => event.agent_name === "Coaching & Response Suggestion Agent");

  if (analysis) {
    $("#intentMetric").textContent = analysis.payload.intent.replaceAll("_", " ");
    $("#sentimentMetric").textContent = analysis.payload.sentiment;
  }

  if (latest) {
    updateRisk(latest.payload.riskScore, latest.payload.level);
    renderAlerts(latest.payload.alerts);
  }

  if (knowledge) {
    renderRecommendations(knowledge.payload.recommendations);
  }

  if (behavior) {
    renderBehavior(behavior.payload.behaviorProfile);
  }

  if (solution) {
    renderPreciseSolution(solution.payload.solution);
  }

  if (customerResolution) {
    renderCustomerResolution(customerResolution.payload.resolution);
  }

  if (representativeAssist) {
    renderRepresentativeAssist(representativeAssist.payload.assist);
  }

  if (coaching) {
    renderCoaching(coaching.payload.coaching);
    $("#suggestedResponse").textContent = buildMoreAiResponses({
      suggestedResponse: coaching.payload.response,
      preciseSolution: solution?.payload.solution,
      riskLevel: latest?.payload.level,
    });
  }

  renderIntentTab({
    intent: analysis?.payload.intent,
    sentiment: analysis?.payload.sentiment,
    riskScore: latest?.payload.riskScore,
    riskLevel: latest?.payload.level,
    customerBehavior: behavior?.payload.behaviorProfile,
    preciseSolution: solution?.payload.solution,
    customerResolution: customerResolution?.payload.resolution,
    representativeAssist: representativeAssist?.payload.assist,
    transferToLiveAgent: representativeAssist?.payload.assist?.takeoverRequired,
    liveAgentReason: representativeAssist?.payload.assist?.takeoverRequired
      ? "High-risk query transferred to representative."
      : "AI can answer this query directly.",
  });
}

function updateRisk(score = 0, level = "low") {
  const badge = $("#riskBadge");
  badge.className = `risk ${level}`;
  badge.textContent = `${level} risk · ${score}`;
}

function renderCoaching(items = []) {
  const list = $("#coachingList");
  list.innerHTML = "";
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderAlerts(items = []) {
  const list = $("#alerts");
  list.innerHTML = "";
  if (items.length === 0) {
    const li = document.createElement("li");
    li.textContent = "No escalation alerts.";
    list.appendChild(li);
  }
  items.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderRecommendations(items = []) {
  const box = $("#recommendations");
  box.innerHTML = "";
  if (items.length === 0) {
    box.innerHTML = `<p>No matching knowledge found.</p>`;
    return;
  }
  items.forEach((item) => {
    const div = document.createElement("div");
    div.className = "recommendation";
    div.innerHTML = `<strong></strong><p></p>`;
    div.querySelector("strong").textContent = `${item.title} · score ${item.score}`;
    div.querySelector("p").textContent = item.content;
    box.appendChild(div);
  });
}

async function sendMessage(event) {
  event.preventDefault();
  if (!state.currentSessionId) {
    await createSession();
  }
  const content = $("#messageInput").value.trim();
  if (!content) return;
  setComposerBusy(true);
  try {
    const data = await api(`/api/sessions/${state.currentSessionId}/messages`, {
      method: "POST",
      body: JSON.stringify({ content }),
    });
    $("#messageInput").value = "";
    if (data.agentOutput) {
      state.lastAgentOutput = data.agentOutput;
      applyAgentOutput(data.agentOutput);
    }
    await loadSession(state.currentSessionId);
    await refreshAnalytics();
  } finally {
    setComposerBusy(false);
  }
}

function setComposerBusy(isBusy) {
  const button = $("#messageForm button[type='submit']");
  button.disabled = isBusy;
  button.textContent = isBusy ? "Thinking..." : "Send";
}

function applyAgentOutput(output) {
  $("#intentMetric").textContent = output.intent.replaceAll("_", " ");
  $("#sentimentMetric").textContent = output.sentiment;
  updateRisk(output.riskScore, output.riskLevel);
  renderBehavior(output.customerBehavior);
  renderCustomerResolution(output.customerResolution);
  renderRepresentativeAssist(output.representativeAssist);
  renderPreciseSolution(output.preciseSolution);
  renderCoaching(output.coaching);
  renderOrchestrator(output);
  renderRecommendations(output.recommendations);
  renderAlerts(output.alerts);
  $("#suggestedResponse").textContent = buildMoreAiResponses(output);
  renderIntentTab(output);
}

function buildMoreAiResponses(output = {}) {
  const response = output.suggestedResponse || "No extra response suggestion available.";
  const efficiency =
    output.riskLevel === "high"
      ? "Efficiency tip: transfer quickly after confirming the issue and summarizing ownership."
      : "Efficiency tip: ask one verification question, then give the next action and timeline.";
  const source = output.preciseSolution?.source
    ? `Knowledge source: ${output.preciseSolution.source}.`
    : "Knowledge source: no matching article.";
  return `${response}\n\n${efficiency}\n${source}`;
}

function renderCustomerResolution(resolution = {}) {
  $("#customerResolution").textContent = resolution.answer || "Customer-facing AI resolution will appear here.";
}

function renderRepresentativeAssist(assist = {}) {
  const takeover = Boolean(assist.takeoverRequired);
  const priority = assist.priority || "low";
  const card = $("#representativeAssistCard");
  card.className = `assist-card ${takeover ? "needs-human" : ""}`;
  $("#assistStatus").textContent = takeover ? "Transferred to you" : "AI handling";
  const badge = $("#assistPriority");
  badge.className = `risk ${priority === "high" ? "high" : priority === "medium" ? "medium" : "low"}`;
  badge.textContent = priority;
  $("#assistSnapshot").textContent = assist.customerSnapshot || "No customer snapshot yet.";
  $("#assistDraft").textContent = assist.draftReply || "No representative draft yet.";
  const list = $("#assistChecklist");
  list.innerHTML = "";
  (assist.resolutionChecklist || []).forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    list.appendChild(li);
  });
}

function renderIntentTab(output = {}) {
  const intent = output.intent || "general_support";
  const sentiment = output.sentiment || "neutral";
  const riskLevel = output.riskLevel || "low";
  const riskScore = output.riskScore ?? 0;
  const behavior = output.customerBehavior || {};
  const solution = output.preciseSolution || {};
  const resolution = output.customerResolution || {};
  const assist = output.representativeAssist || {};
  const route = output.transferToLiveAgent || assist.takeoverRequired ? "Representative" : "AI Resolution";

  $("#heroIntent").textContent = `Intent: ${intent.replaceAll("_", " ")}`;
  $("#heroRoute").textContent = `Route: ${route}`;
  $("#intentTabTitle").textContent = intent.replaceAll("_", " ");
  $("#intentTabSummary").textContent = behavior.summary || "Intent detected from customer query.";
  $("#intentTabSentiment").textContent = `Sentiment: ${sentiment}`;
  $("#intentTabRisk").textContent = `Risk: ${riskLevel} (${riskScore})`;
  $("#intentTabRoute").textContent = `Route: ${route}`;
  $("#intentSource").textContent = solution.source || resolution.source || "No RAG source yet";
  $("#intentResolutionPreview").textContent =
    resolution.answer || solution.answer || "Resolution preview will appear here.";
  $("#intentRoutingTitle").textContent =
    route === "Representative" ? "Transfer to representative" : "AI answers customer";
  $("#intentRoutingReason").textContent =
    route === "Representative"
      ? assist.customerSnapshot || output.liveAgentReason || "High escalation risk detected."
      : "Risk is low or medium, so AI can answer using retrieved support knowledge.";

  const list = $("#intentSignals");
  list.innerHTML = "";
  (behavior.signals || ["No behavior signals yet."]).forEach((signal) => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}

function renderBehavior(behavior = {}) {
  $("#behaviorSummary").textContent = behavior.summary || "No behavior profile available.";
  const list = $("#behaviorSignals");
  list.innerHTML = "";
  (behavior.signals || []).forEach((signal) => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}

function renderPreciseSolution(solution = {}) {
  $("#preciseSolution").textContent = solution.answer || "No precise solution available.";
  const list = $("#solutionSteps");
  list.innerHTML = "";
  (solution.steps || []).forEach((step) => {
    const li = document.createElement("li");
    li.textContent = step;
    list.appendChild(li);
  });
}

function renderOrchestrator(output = {}) {
  $("#orchestratorMode").textContent = output.orchestratorMode || "rules_fallback";
  const handoff = $("#liveAgentStatus");
  if (output.transferToLiveAgent) {
    handoff.className = "handoff-status transferred";
    handoff.textContent = output.liveAgentReason || "Transferred to a live agent.";
  } else {
    handoff.className = "handoff-status";
    handoff.textContent = "Live agent transfer not required.";
  }
  const list = $("#orchestratorNotes");
  list.innerHTML = "";
  (output.orchestratorNotes || []).forEach((note) => {
    const li = document.createElement("li");
    li.textContent = note;
    list.appendChild(li);
  });
}

async function createSummary() {
  if (!state.currentSessionId) return;
  const summary = await api(`/api/sessions/${state.currentSessionId}/summary`, {
    method: "POST",
    body: JSON.stringify({}),
  });
  renderSummary(summary);
  await refreshSessions();
  await refreshAnalytics();
}

function renderSummary(summary) {
  const card = $("#summaryCard");
  if (!summary) {
    card.innerHTML = "Post-interaction summary will appear here.";
    return;
  }
  card.innerHTML = `
    <strong>Score ${summary.score}</strong>
    <p>${summary.summary}</p>
    <p><strong>Primary intent:</strong> ${summary.primaryIntent.replaceAll("_", " ")}</p>
    <p><strong>Training focus:</strong> ${summary.nextTrainingFocus.join(" ")}</p>
  `;
}

async function refreshDocuments() {
  const documents = await api("/api/documents");
  renderList(
    $("#documents"),
    documents,
    (doc) => {
      const div = document.createElement("div");
      div.className = "doc-item";
      div.innerHTML = `<strong></strong><p></p>`;
      div.querySelector("strong").textContent = doc.title;
      div.querySelector("p").textContent = `${doc.chunks} chunks indexed`;
      return div;
    },
    "No documents indexed."
  );
}

async function refreshSocialPosts() {
  const posts = await api("/api/social-posts");
  $("#socialStatus").textContent = `${posts.length} labeled social posts available`;
  renderList(
    $("#socialPosts"),
    posts,
    (post) => {
      const div = document.createElement("div");
      div.className = "doc-item social-post";
      const meta = `${post.source} | ${post.intent.replaceAll("_", " ")} | ${post.sentiment} | risk ${post.risk_score}`;
      div.innerHTML = `<strong></strong><p></p><small></small>`;
      div.querySelector("strong").textContent = meta;
      div.querySelector("p").textContent = post.content;
      div.querySelector("small").textContent = `Keywords: ${post.keywords.slice(0, 8).join(", ") || "none"}`;
      return div;
    },
    "No social posts imported yet."
  );
}

async function fetchSocialPosts(event) {
  event.preventDefault();
  const query = $("#xQuery").value.trim();
  if (!query) return;
  $("#socialStatus").textContent = "Fetching from X API...";
  try {
    const result = await api("/api/social-posts/fetch", {
      method: "POST",
      body: JSON.stringify({ query, maxResults: 10 }),
    });
    $("#socialStatus").textContent = `Imported ${result.imported} X posts`;
  } catch (error) {
    $("#socialStatus").textContent = "Live fetch needs X_BEARER_TOKEN. Use demo or manual import.";
  }
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function importDemoTweets() {
  const result = await api("/api/social-posts/import", {
    method: "POST",
    body: JSON.stringify({ demo: true }),
  });
  $("#socialStatus").textContent = `Imported ${result.imported} demo tweets`;
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function importSocialText(event) {
  event.preventDefault();
  const content = $("#socialContent").value.trim();
  if (!content) return;
  const result = await api("/api/social-posts/import", {
    method: "POST",
    body: JSON.stringify({ content, source: "manual" }),
  });
  $("#socialContent").value = "";
  $("#socialStatus").textContent = `Imported ${result.imported} manual posts`;
  await refreshSocialPosts();
  await refreshAnalytics();
}

async function createTrainingSnapshot() {
  const snapshot = await api("/api/training-snapshots", {
    method: "POST",
    body: JSON.stringify({}),
  });
  $("#trainingSnapshot").innerHTML = `
    <strong>${snapshot.examples} labeled examples | ${snapshot.status.replaceAll("_", " ")}</strong>
    <p>Average risk: ${snapshot.averageRisk}. High-risk examples: ${snapshot.highRiskExamples}.</p>
    <p><strong>Intent distribution:</strong> ${formatDistribution(snapshot.intentDistribution)}</p>
    <p><strong>Sentiment distribution:</strong> ${formatDistribution(snapshot.sentimentDistribution)}</p>
  `;
}

function formatDistribution(value) {
  const entries = Object.entries(value || {});
  if (entries.length === 0) return "none";
  return entries.map(([key, count]) => `${key.replaceAll("_", " ")} ${count}`).join(", ");
}

async function addDocument(event) {
  event.preventDefault();
  const title = $("#docTitle").value.trim();
  const content = $("#docContent").value.trim();
  if (!content) return;
  await api("/api/documents", {
    method: "POST",
    body: JSON.stringify({ title, content }),
  });
  $("#docTitle").value = "";
  $("#docContent").value = "";
  await refreshDocuments();
  await refreshAnalytics();
}

async function refreshAnalytics() {
  const [analytics, settings] = await Promise.all([api("/api/analytics"), api("/api/settings")]);
  const cards = [
    ["Sessions", analytics.sessions],
    ["Messages", analytics.messages],
    ["Documents", analytics.documents],
    ["RAG vectors", analytics.ragVectors],
    ["Social posts", analytics.socialPosts],
    ["Max risk", analytics.maxRisk],
    ["Avg score", analytics.averageScore],
    ["Medium threshold", settings.riskThresholds.medium],
    ["High threshold", settings.riskThresholds.high],
    ["LLM mode", settings.llm.mode],
    ["LLM model", settings.llm.model],
  ];
  $("#analyticsCards").innerHTML = cards
    .map(([label, value]) => `<div><strong>${value}</strong><span>${label}</span></div>`)
    .join("");
}

$("#newSessionBtn").addEventListener("click", createSession);
$("#summaryBtn").addEventListener("click", createSummary);
$("#messageForm").addEventListener("submit", sendMessage);
$("#documentForm").addEventListener("submit", addDocument);
$("#socialFetchForm").addEventListener("submit", fetchSocialPosts);
$("#demoTweetsBtn").addEventListener("click", importDemoTweets);
$("#socialImportForm").addEventListener("submit", importSocialText);
$("#trainingSnapshotBtn").addEventListener("click", createTrainingSnapshot);
document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => {
    $("#messageInput").value = button.dataset.prompt;
    $("#messageInput").focus();
  });
});

boot();
